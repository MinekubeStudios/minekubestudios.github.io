<template>
	<span
		v-if="showLabel"
		class="flex h-10 items-center text-nowrap text-base font-medium text-primary"
		:aria-label="useFilterIcon ? effectiveLabel : undefined"
	>
		<FilterIcon v-if="useFilterIcon" class="size-5 text-primary" aria-hidden="true" />
		<template v-else>{{ effectiveLabel }}</template>
	</span>

	<template v-for="preview in appliedFilterPreviews" :key="preview.key">
		<Button
			v-if="preview.category.direct"
			type="outlined"
			native-type="button"
			size="lg"
			:class="effectivePreviewTriggerClass"
			:aria-label="formatMessage(messages.clearNamedFilter, { name: preview.label })"
			@click="clearFilterCategory(preview.key)"
		>
			<span class="font-semibold">{{ preview.label }}</span>
			<XIcon class="size-4" />
		</Button>
		<MultiSelect
			v-else
			class="min-w-0 max-w-full"
			:model-value="getPreviewSelectedValues(preview.key)"
			:options="preview.options"
			:max-height="500"
			:clearable="false"
			:show-chevron="false"
			:fit-content="true"
			:searchable="preview.category.searchable"
			:search-placeholder="preview.category.searchPlaceholder"
			trigger-type="base"
			trigger-size="lg"
			:trigger-class="effectivePreviewTriggerClass"
			:dropdown-width="getPreviewDropdownWidth(preview.category)"
			:dropdown-min-width="getPreviewDropdownMinWidth(preview.category)"
			:checkbox-position="checkboxPosition"
			show-selection-actions
			@update:model-value="(nextValue) => setPreviewSelectedValues(preview.key, nextValue)"
			@open="openPreviewFilterDraft(preview.key)"
			@close="commitPreviewFilterDraft(preview.key)"
		>
			<template v-if="$slots['preview-top'] && preview.category.syntheticOptions?.length" #top>
				<slot
					name="preview-top"
					:category="preview.category"
					:selected-values="getPreviewSelectedValues(preview.key)"
					:set-selected-values="(values) => setPreviewSelectedValues(preview.key, values)"
					:close-menu="(event) => closePreviewFilterMenu(preview.key, event)"
				></slot>
			</template>
			<template v-if="$slots['search-actions']" #search-actions>
				<slot
					name="search-actions"
					:category="preview.category"
					:selected-values="getPreviewSelectedValues(preview.key)"
					:set-selected-values="(values) => setPreviewSelectedValues(preview.key, values)"
					:close-menu="(event) => closePreviewFilterMenu(preview.key, event)"
				></slot>
			</template>
			<template #input-content="{ isOpen, openDirection }">
				<div class="flex min-h-8 min-w-0 max-w-full items-center gap-2 sm:max-w-80">
					<FilterIcon
						v-if="showPreviewFilterIcon"
						class="size-5 shrink-0 text-primary"
						aria-hidden="true"
					/>
					<slot
						name="preview-content"
						:category="preview.category"
						:selected-values="getPreviewSelectedValues(preview.key)"
						:label="preview.label"
						:summary="preview.summary"
					>
						<span class="min-w-0 flex-1 truncate">
							<span class="font-medium">{{ preview.label }}:</span>
							<span class="ml-1 font-semibold text-contrast">{{ preview.summary }}</span>
						</span>
					</slot>
					<div class="flex shrink-0 items-center gap-1.5">
						<button
							type="button"
							class="flex cursor-pointer items-center justify-center rounded border-none bg-transparent p-0.5 text-secondary transition-colors hover:text-contrast"
							:aria-label="formatMessage(messages.clearNamedFilter, { name: preview.label })"
							@click.stop="clearFilterCategory(preview.key)"
						>
							<XIcon class="size-4 text-primary" />
						</button>
						<div class="h-5 w-[1px] shrink-0 bg-surface-5"></div>
						<ChevronLeftIcon
							class="size-5 shrink-0 text-secondary transition-transform duration-150"
							:class="
								isOpen ? (openDirection === 'down' ? 'rotate-90' : '-rotate-90') : '-rotate-90'
							"
						/>
					</div>
				</div>
			</template>
			<template v-if="$slots['preview-footer']" #bottom>
				<slot
					name="preview-footer"
					:category="preview.category"
					:selected-values="getPreviewSelectedValues(preview.key)"
					:set-selected-values="(values) => setPreviewSelectedValues(preview.key, values)"
					:close-menu="(event) => closePreviewFilterMenu(preview.key, event)"
				></slot>
			</template>
			<template v-if="$slots.option" #option="{ item, selected, index }">
				<slot
					name="option"
					:category="preview.category"
					:option="item"
					:selected="selected"
					:index="index"
				></slot>
			</template>
			<template v-else-if="$slots['option-right']" #option-right="{ item, selected, index }">
				<slot
					name="option-right"
					:category="preview.category"
					:option="item"
					:selected="selected"
					:index="index"
				></slot>
			</template>
		</MultiSelect>
	</template>

	<div class="flex h-10 min-w-0 max-w-full items-center gap-2">
		<Button
			ref="addMenuTrigger"
			type="outlined"
			native-type="button"
			:size="addButtonSize"
			:class="addButtonClass ?? '!border'"
			:aria-expanded="isAddMenuOpen"
			aria-haspopup="menu"
			@click="handleAddMenuTriggerClick"
			@keydown="handleAddMenuTriggerKeydown"
		>
			<PlusIcon />
			{{ effectiveAddLabel }}
		</Button>

		<Button v-if="shouldShowClear" type="quiet" native-type="button" @click="clearAllFilters">{{
			effectiveClearLabel
		}}</Button>
	</div>

	<Teleport v-if="isClient" to="#teleports">
		<Transition name="floating-expand" :css="!isMobileAddMenuLayout">
			<div
				v-if="isAddMenuOpen && !isMobileActiveSubmenu"
				ref="menuContainer"
				class="fixed z-[9999] flex flex-col overflow-x-hidden overflow-y-auto rounded-[14px] border border-solid border-surface-5 bg-surface-4 shadow-2xl"
				:style="addMenuStyle"
				role="menu"
				@pointerdown.stop
				@mousedown.stop
				@keydown="handleAddMenuKeydown"
				@mousemove="(event) => handleMenuMouseMove(event, 'menu')"
			>
				<button
					v-for="category in filterCategories"
					:key="category.key"
					:ref="(element) => setCategoryButtonRef(category.key, element)"
					type="button"
					class="group/filter-menu-button flex h-12 w-full appearance-none items-center justify-between gap-1 border-0 px-4 text-left text-base font-semibold text-primary shadow-none transition-all duration-150 hover:brightness-110 focus:brightness-110 bg-surface-4"
					:class="
						category.key === activeCategoryKey || isDirectCategorySelected(category)
							? '!brightness-110'
							: ''
					"
					:role="category.direct ? 'menuitemcheckbox' : 'menuitem'"
					:aria-checked="category.direct ? isDirectCategorySelected(category) : undefined"
					@click="handleCategoryClick(category)"
					@mouseenter="handleCategoryMouseEnter(category)"
					@focus="handleCategoryFocus(category)"
				>
					<span>{{ category.label }}</span>
					<div class="flex items-center gap-1">
						<CheckIcon
							v-if="category.direct && isDirectCategorySelected(category)"
							class="size-5 text-brand"
						/>
						<ChevronRightIcon v-else-if="!category.direct" class="size-5 text-secondary" />
					</div>
				</button>
			</div>
		</Transition>
	</Teleport>

	<Teleport v-if="isClient" to="#teleports">
		<Transition name="floating-expand" :css="!isMobileAddMenuLayout">
			<div
				v-if="isAddMenuOpen && activeCategory && (isMobileAddMenuLayout || hasSubmenuPosition)"
				ref="submenu"
				class="fixed z-[10000] flex max-h-[min(70vh,32rem)] max-w-[calc(100vw-1rem)] flex-col overflow-hidden rounded-[14px] border border-solid border-surface-5 bg-surface-4 shadow-2xl"
				:class="activeCategory.submenuClass ?? DEFAULT_SUBMENU_CLASS"
				:style="submenuStyle"
				@mouseenter="handleSubmenuMouseEnter"
				@mouseleave="handleSubmenuMouseLeave"
				@keydown="handleAddMenuKeydown"
				@mousemove="(event) => handleMenuMouseMove(event, 'submenu')"
			>
				<div
					v-if="isMobileAddMenuLayout"
					class="flex items-center border-0 border-b border-solid border-b-surface-5 bg-surface-4"
				>
					<button
						type="button"
						class="flex h-12 w-full items-center gap-2 border-0 bg-transparent px-4 text-left text-base font-semibold text-primary shadow-none transition-all hover:brightness-110 focus-visible:brightness-110"
						@click="returnToCategoryMenu"
					>
						<ChevronLeftIcon class="size-5 shrink-0 text-secondary" />
						<span class="min-w-0 truncate">{{ activeCategory.label }}</span>
					</button>
				</div>
				<div
					v-if="activeCategory.searchable"
					class="flex justify-between border-0 border-b border-solid border-b-surface-5 py-1.5 w-full"
				>
					<Input
						v-model="categorySearchQuery"
						:icon="SearchIcon"
						type="text"
						:placeholder="
							activeCategory.searchPlaceholder ?? formatMessage(messages.searchPlaceholder)
						"
						wrapper-class="grow bg-surface-4 mx-1"
						input-class="ps-9 mx-1.5"
					/>
					<slot
						name="search-actions"
						:category="activeCategory"
						:selected-values="activeCategorySelectedValues"
						:set-selected-values="setActiveCategorySelectedValues"
						:close-menu="closeAddMenu"
					></slot>
				</div>

				<div
					v-if="$slots['category-top']"
					class="border-0 border-b border-solid border-b-surface-5"
				>
					<slot
						name="category-top"
						:category="activeCategory"
						:selected-values="activeCategorySelectedValues"
						:set-selected-values="setActiveCategorySelectedValues"
						:close-menu="closeAddMenu"
					></slot>
				</div>

				<div
					class="flex items-center justify-between gap-3 border-0 border-b border-solid border-b-surface-5 px-4 py-2.5 text-sm"
				>
					<span class="font-semibold text-secondary">{{ activeCategorySelectionLabel }}</span>
					<button
						type="button"
						class="border-0 bg-transparent p-0 text-sm font-semibold text-secondary shadow-none transition-colors"
						:class="
							hasActiveCategorySelection
								? 'hover:bg-transparent hover:text-contrast'
								: 'cursor-not-allowed opacity-50'
						"
						:disabled="!hasActiveCategorySelection"
						@click="clearActiveCategorySelection"
						@keydown.enter.stop
						@keydown.space.stop
					>
						Clear
					</button>
				</div>
				<div
					ref="activeCategoryOptionsScrollbar"
					class="dropdown-filter-bar-options-scrollbar min-h-0 flex-1 bg-surface-4"
					data-overlayscrollbars-initialize
				>
					<div
						ref="activeCategoryOptionsContainer"
						class="h-full min-h-0 overflow-y-auto"
						data-overlayscrollbars-viewport
					>
						<div
							v-if="filteredActiveCategoryOptions.length === 0"
							class="px-4 py-3.5 text-base font-medium text-secondary"
						>
							{{ activeCategoryEmptyStateLabel }}
						</div>
						<div
							v-else
							ref="activeCategoryOptionsListContainer"
							:class="shouldVirtualizeActiveCategoryOptions ? 'relative' : 'flex flex-col'"
							:style="activeCategoryOptionsListStyle"
						>
							<div
								v-for="{ item, index } in renderedVisibleActiveCategoryOptions"
								:key="getActiveCategoryItemKey(item, index)"
								:class="
									shouldVirtualizeActiveCategoryOptions ? 'absolute left-0 right-0' : undefined
								"
								:style="getActiveCategoryOptionWrapperStyle(index)"
							>
								<div
									v-if="isDropdownFilterSectionHeader(item)"
									class="flex items-center justify-between gap-3 border-0 px-4 py-2.5 text-sm font-semibold text-secondary"
									:class="[
										item.class,
										item.dividerBefore && index > 0
											? 'border-t border-solid border-surface-5'
											: undefined,
									]"
								>
									<span class="flex min-w-0 items-center gap-2">
										<component
											:is="item.icon"
											v-if="item.icon"
											class="size-4 shrink-0"
											aria-hidden="true"
										/>
										<span class="min-w-0 truncate">{{ item.label }}</span>
									</span>
									<button
										v-if="hasSelectableSectionHeaderOptions(item)"
										type="button"
										class="border-0 bg-transparent p-0 text-sm font-semibold text-secondary shadow-none transition-colors hover:text-contrast"
										@click="toggleSectionHeaderOptions(item)"
									>
										{{
											formatMessage(
												areSectionHeaderOptionsSelected(item) ? messages.clear : messages.selectAll,
											)
										}}
									</button>
								</div>
								<button
									v-else
									type="button"
									class="flex w-full cursor-pointer items-center gap-2.5 border-0 px-4 py-3.5 text-left text-contrast shadow-none transition-all duration-150 bg-surface-4 hover:brightness-[115%] focus-visible:brightness-[115%] focus-visible:outline-none"
									:class="[
										shouldVirtualizeActiveCategoryOptions ? 'h-12' : undefined,
										{
											'brightness-[115%]': item.selected,
											'pointer-events-none cursor-not-allowed opacity-50': item.disabled,
										},
									]"
									:aria-disabled="item.disabled || undefined"
									:aria-checked="item.selected"
									role="checkbox"
									@click="toggleFilterOption(activeCategory.key, item)"
								>
									<span
										v-if="checkboxPosition === 'left'"
										class="checkbox-shadow flex h-5 w-5 shrink-0 items-center justify-center rounded-md border-[1px] border-solid"
										:class="
											item.selected
												? 'border-button-border bg-brand text-brand-inverted'
												: 'border-surface-5 bg-surface-2'
										"
									>
										<CheckIcon v-if="item.selected" aria-hidden="true" stroke-width="3" />
									</span>
									<div class="flex min-w-0 flex-1 items-center justify-between gap-3">
										<slot
											v-if="$slots.option"
											name="option"
											:category="activeCategory"
											:option="item"
											:selected="item.selected"
											:index="index"
										></slot>
										<template v-else>
											<span
												class="min-w-0 truncate font-semibold leading-tight"
												:class="item.selected ? 'text-contrast' : 'text-primary'"
											>
												{{ item.label }}
											</span>
											<slot
												name="option-right"
												:category="activeCategory"
												:option="item"
												:selected="item.selected"
											></slot>
										</template>
									</div>
									<span
										v-if="checkboxPosition === 'right'"
										class="flex shrink-0 items-center justify-center text-brand"
									>
										<CheckIcon v-if="item.selected" aria-hidden="true" class="size-5" />
									</span>
								</button>
							</div>
						</div>
					</div>
				</div>
				<slot
					name="category-footer"
					:category="activeCategory"
					:selected-values="activeCategorySelectedValues"
					:set-selected-values="setActiveCategorySelectedValues"
					:close-menu="closeAddMenu"
				></slot>
			</div>
		</Transition>
	</Teleport>
</template>

<script setup lang="ts">
import 'overlayscrollbars/overlayscrollbars.css'

import {
	CheckIcon,
	ChevronLeftIcon,
	ChevronRightIcon,
	FilterIcon,
	PlusIcon,
	SearchIcon,
	XIcon,
} from '@modrinth/assets'
import { onClickOutside } from '@vueuse/core'
import { OverlayScrollbars, type PartialOptions } from 'overlayscrollbars'
import type { Component, ComponentPublicInstance, CSSProperties } from 'vue'
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { Button, type ButtonElementHandle, type ButtonSize } from '#ui/components/base/buttons'

import { defineMessages, useVIntl } from '../../composables/i18n'
import { useVirtualScroll } from '../../composables/virtual-scroll'
import { dismissTooltip } from '../../providers/tooltip'
import Input from './inputs/Input.vue'
import MultiSelect, { type MultiSelectItem } from './MultiSelect.vue'

export type DropdownFilterBarOption = {
	value: string
	label: string
	searchTerms?: string[]
	disabled?: boolean
}

export type DropdownFilterBarSectionHeader = {
	type: 'section-header'
	label: string
	key?: string
	icon?: Component
	class?: string
	dividerBefore?: boolean
}

export type DropdownFilterBarItem = DropdownFilterBarOption | DropdownFilterBarSectionHeader

export type DropdownFilterBarCategory = {
	key: string
	label: string
	options: DropdownFilterBarItem[]
	direct?: boolean
	syntheticOptions?: DropdownFilterBarOption[]
	searchable?: boolean
	disableLocalOptionsFilter?: boolean
	searchPlaceholder?: string
	emptyOptionsLabel?: string
	emptySearchLabel?: string
	onSearchQueryChange?: (query: string) => void
	submenuClass?: string
	previewDropdownWidth?: string | number
	previewDropdownMinWidth?: string | number
}

type DropdownFilterBarValue = Record<string, string[]>

type RenderedDropdownFilterBarOption = DropdownFilterBarOption & {
	selected: boolean
}

type RenderedDropdownFilterBarItem =
	| RenderedDropdownFilterBarOption
	| DropdownFilterBarSectionHeader

type VisibleDropdownFilterBarOption = {
	item: RenderedDropdownFilterBarItem
	index: number
}

type OverlayScrollbarsInstance = NonNullable<ReturnType<typeof OverlayScrollbars>>

type Point = {
	x: number
	y: number
}

type ViewportRect = {
	width: number
	height: number
	offsetTop: number
	offsetLeft: number
}

type MenuPositionOptions = {
	triggerRect: DOMRect
	dropdownRect: DOMRect
	dropdownHeight: number
	viewport: ViewportRect
}

type SubmenuPositionOptions = {
	buttonRect: DOMRect
	openDirection: SubmenuOpenDirection
	submenuWidth: number
	submenuHeight: number
	viewport: ViewportRect
}

type SubmenuOpenDirection = 'left' | 'right'

type SubmenuOpenDirectionOptions = {
	menuRect: DOMRect
	widestSubmenuWidth: number
	viewport: ViewportRect
}

const ADD_MENU_WIDTH = 250
const DROPDOWN_GAP = 8
const DROPDOWN_VIEWPORT_MARGIN = 8
const DEFAULT_ROOT_FONT_SIZE = 16
const DEFAULT_SUBMENU_CLASS = 'w-72'
const DEFAULT_SUBMENU_WIDTH = '18rem'
const DEFAULT_PREVIEW_DROPDOWN_MIN_WIDTH = '18rem'
const DROPDOWN_FILTER_OPTION_ROW_HEIGHT = 48
const DROPDOWN_FILTER_VIRTUALIZATION_THRESHOLD = 80
const MOBILE_ADD_MENU_LAYOUT_QUERY = '(pointer: coarse), (max-width: 800px)'
const OPTIONS_OVERLAY_SCROLLBARS_OPTIONS = Object.freeze<PartialOptions>({
	overflow: {
		x: 'hidden',
		y: 'scroll',
	},
	scrollbars: {
		theme: 'os-theme-modrinth',
		autoHide: 'leave',
		autoHideSuspend: true,
	},
})
const TAILWIND_WIDTH_CLASS_SIZE: Record<string, string> = {
	[DEFAULT_SUBMENU_CLASS]: DEFAULT_SUBMENU_WIDTH,
}

const { formatMessage } = useVIntl()
const messages = defineMessages({
	filteredBy: { id: 'filter-bar.filtered-by', defaultMessage: 'Filtered by' },
	add: { id: 'filter-bar.add', defaultMessage: 'Add' },
	clear: { id: 'filter-bar.clear', defaultMessage: 'Clear' },
	selectAll: { id: 'filter-bar.select-all', defaultMessage: 'Select all' },
	noOptions: { id: 'filter-bar.no-options', defaultMessage: 'No options available.' },
	noSearchResults: { id: 'filter-bar.no-search-results', defaultMessage: 'No options found.' },
	searchPlaceholder: { id: 'filter-bar.search-placeholder', defaultMessage: 'Search...' },
	clearNamedFilter: {
		id: 'filter-bar.clear-named-filter',
		defaultMessage: 'Clear {name} filter',
	},
})

const props = withDefaults(
	defineProps<{
		modelValue: DropdownFilterBarValue
		categories: DropdownFilterBarCategory[]
		label?: string
		addLabel?: string
		clearLabel?: string
		showClear?: boolean
		showLabel?: boolean
		useFilterIcon?: boolean
		applyImmediately?: boolean
		showPreviewFilterIcon?: boolean
		previewTriggerClass?: string
		addButtonClass?: string
		addButtonSize?: ButtonSize
		emptyOptionsLabel?: string
		emptySearchLabel?: string
		checkboxPosition?: 'left' | 'right'
	}>(),
	{
		showClear: false,
		showLabel: true,
		useFilterIcon: false,
		addButtonSize: 'md',
		applyImmediately: false,
		showPreviewFilterIcon: false,
		checkboxPosition: 'left',
	},
)

const effectiveLabel = computed(() => props.label ?? formatMessage(messages.filteredBy))
const effectiveAddLabel = computed(() => props.addLabel ?? formatMessage(messages.add))
const effectiveClearLabel = computed(() => props.clearLabel ?? formatMessage(messages.clear))
const effectiveEmptyOptionsLabel = computed(
	() => props.emptyOptionsLabel ?? formatMessage(messages.noOptions),
)
const effectiveEmptySearchLabel = computed(
	() => props.emptySearchLabel ?? formatMessage(messages.noSearchResults),
)

const emit = defineEmits<{
	'update:modelValue': [value: DropdownFilterBarValue]
	clear: []
}>()

const isAddMenuOpen = ref(false)
const isClient = ref(false)
const activeCategoryKey = ref<string | null>(null)
const pendingCategoryKey = ref<string | null>(null)
const draftSelectedFilters = ref<DropdownFilterBarValue>(cloneSelectedFilters(props.modelValue))
const previewSelectedValueDrafts = ref<Partial<DropdownFilterBarValue>>({})
const categorySearchQuery = ref('')
const lastMousePosition = ref<Point | null>(null)
const isCursorInsideSubmenu = ref(false)
const hasSubmenuPosition = ref(false)
const isMobileAddMenuLayout = ref(false)
const submenuOpenDirection = ref<SubmenuOpenDirection>('right')
const addMenuTrigger = ref<ButtonElementHandle | null>(null)
const menuContainer = ref<HTMLElement | null>(null)
const submenu = ref<HTMLElement | null>(null)
const activeCategoryOptionsScrollbar = ref<HTMLElement | null>(null)
const activeCategoryOptionsContainer = ref<HTMLElement | null>(null)
const activeCategoryOptionsOverlayScrollbars = ref<OverlayScrollbarsInstance | null>(null)
const addMenuStyle = ref<CSSProperties>({
	left: '0px',
	minWidth: '0px',
	top: '0px',
	width: `${ADD_MENU_WIDTH}px`,
})
const submenuPosition = ref<Point>({ x: 0, y: 0 })
const categoryButtonRefs = new Map<string, HTMLElement>()
let pendingCategoryTimeout: ReturnType<typeof setTimeout> | null = null
let previousMousePosition: Point | null = null
let addMenuPositionRafId: number | null = null

function isDropdownFilterSectionHeader(
	item: DropdownFilterBarItem | RenderedDropdownFilterBarItem,
): item is DropdownFilterBarSectionHeader {
	return 'type' in item && item.type === 'section-header'
}

function isDropdownFilterOption(
	item: DropdownFilterBarItem | RenderedDropdownFilterBarItem,
): item is DropdownFilterBarOption {
	return !isDropdownFilterSectionHeader(item)
}

const filterCategories = computed<DropdownFilterBarCategory[]>(() => {
	const source = isAddMenuOpen.value ? 'draft' : 'committed'
	return props.categories.map((category) => {
		const syntheticValues = getCategorySyntheticValueSet(category)
		const selectedValues = getSelectedValues(category.key, source).filter(
			(value) => !syntheticValues.has(value),
		)

		return {
			...category,
			options: getOptionsWithSelectedValues(category.options, selectedValues),
		}
	})
})

const filterCategoriesByKey = computed(
	() => new Map(filterCategories.value.map((category) => [category.key, category] as const)),
)

const activeCategory = computed(() =>
	activeCategoryKey.value ? filterCategoriesByKey.value.get(activeCategoryKey.value) : undefined,
)
const activeCategorySelectionCount = computed(() => {
	return activeCategory.value ? getCategorySelectionCount(activeCategory.value.key, 'draft') : 0
})
const hasActiveCategorySelection = computed(() => activeCategorySelectionCount.value > 0)
const activeCategorySelectionLabel = computed(() => {
	return activeCategorySelectionCount.value === 1
		? '1 selected'
		: `${activeCategorySelectionCount.value} selected`
})
const activeCategorySelectedValues = computed(() =>
	activeCategory.value ? getSelectedValues(activeCategory.value.key, 'draft') : [],
)
const activeCategorySelectedValueSet = computed(() => new Set(activeCategorySelectedValues.value))

const filteredActiveCategoryOptions = computed(() => {
	if (!activeCategory.value) {
		return []
	}

	if (!activeCategory.value.searchable || activeCategory.value.disableLocalOptionsFilter) {
		return activeCategory.value.options
	}

	const query = categorySearchQuery.value.trim().toLowerCase()
	if (!query) {
		return activeCategory.value.options
	}

	const items: DropdownFilterBarItem[] = []
	let pendingSectionHeader: DropdownFilterBarSectionHeader | null = null

	for (const option of activeCategory.value.options) {
		if (isDropdownFilterSectionHeader(option)) {
			pendingSectionHeader = option
			continue
		}

		const matches =
			option.label.toLowerCase().includes(query) ||
			option.value.toLowerCase().includes(query) ||
			(option.searchTerms?.some((term) => term.toLowerCase().includes(query)) ?? false)

		if (!matches) {
			continue
		}

		if (pendingSectionHeader) {
			items.push(pendingSectionHeader)
			pendingSectionHeader = null
		}
		items.push(option)
	}

	return items
})

const shouldVirtualizeActiveCategoryOptions = computed(
	() => filteredActiveCategoryOptions.value.length > DROPDOWN_FILTER_VIRTUALIZATION_THRESHOLD,
)

const {
	listContainer: activeCategoryOptionsListContainer,
	totalHeight: activeCategoryOptionsTotalHeight,
	visibleRange: activeCategoryOptionsVisibleRange,
	visibleItems: visibleActiveCategoryOptions,
	resetScrollState: resetActiveCategoryOptionsVirtualScrollState,
	syncScrollState: syncActiveCategoryOptionsVirtualScrollState,
} = useVirtualScroll(filteredActiveCategoryOptions, {
	itemHeight: DROPDOWN_FILTER_OPTION_ROW_HEIGHT,
	bufferSize: 8,
	initialItemCount: 12,
	enabled: shouldVirtualizeActiveCategoryOptions,
})

const renderedVisibleActiveCategoryOptions = computed<VisibleDropdownFilterBarOption[]>(() =>
	visibleActiveCategoryOptions.value.map((item, offset) => ({
		item: isDropdownFilterSectionHeader(item)
			? item
			: {
					...item,
					selected: activeCategorySelectedValueSet.value.has(item.value),
				},
		index: activeCategoryOptionsVisibleRange.value.start + offset,
	})),
)

const activeCategoryOptionsListStyle = computed<CSSProperties | undefined>(() =>
	shouldVirtualizeActiveCategoryOptions.value
		? { height: `${activeCategoryOptionsTotalHeight.value}px` }
		: undefined,
)

const activeCategoryEmptyStateLabel = computed(() => {
	const category = activeCategory.value
	if (!category) {
		return effectiveEmptyOptionsLabel.value
	}

	return category.searchable && categorySearchQuery.value.trim().length > 0
		? (category.emptySearchLabel ?? effectiveEmptySearchLabel.value)
		: (category.emptyOptionsLabel ?? effectiveEmptyOptionsLabel.value)
})

const submenuStyle = computed<CSSProperties>(() => {
	if (isMobileAddMenuLayout.value) {
		return {
			left: addMenuStyle.value.left,
			top: addMenuStyle.value.top,
		}
	}

	return {
		left: `${submenuPosition.value.x}px`,
		top: `${submenuPosition.value.y}px`,
	}
})
const isMobileActiveSubmenu = computed(
	() =>
		isMobileAddMenuLayout.value && activeCategory.value !== undefined && hasSubmenuPosition.value,
)
const addMenuTriggerElement = computed(() => addMenuTrigger.value?.element ?? null)
const addMenuOutsideClickTarget = computed(() => menuContainer.value ?? submenu.value)
const addMenuOutsideClickIgnore = computed(() => [addMenuTriggerElement, menuContainer, submenu])

const appliedFilterPreviews = computed(() =>
	Object.entries(props.modelValue)
		.map(([categoryKey, selectedValues]) => {
			const category = filterCategoriesByKey.value.get(categoryKey)
			if (!category || selectedValues.length === 0) {
				return undefined
			}

			return {
				key: category.key,
				label: category.label,
				summary: getCategorySelectionSummary(category),
				count: selectedValues.length,
				category,
				options: getVisiblePreviewOptions(category),
			}
		})
		.filter((preview): preview is NonNullable<typeof preview> => preview !== undefined),
)

const hasAppliedFilters = computed(() => appliedFilterPreviews.value.length > 0)
const shouldShowClear = computed(() => hasAppliedFilters.value || props.showClear)
const DEFAULT_PREVIEW_TRIGGER_CLASS = 'max-w-[16rem] !rounded-xl'
const effectivePreviewTriggerClass = computed(
	() => (props.previewTriggerClass ?? DEFAULT_PREVIEW_TRIGGER_CLASS) + ' h-9',
)

function cloneSelectedFilters(filters: DropdownFilterBarValue): DropdownFilterBarValue {
	return Object.fromEntries(
		Object.entries(filters).map(([categoryKey, values]) => [
			categoryKey,
			normalizeSelectedValues(values),
		]),
	)
}

function normalizeSelectedValues(values: string[]): string[] {
	return Array.from(new Set(values))
}

function areStringArraysEqual(left: string[], right: string[]): boolean {
	if (left.length !== right.length) {
		return false
	}

	for (let index = 0; index < left.length; index += 1) {
		if (left[index] !== right[index]) {
			return false
		}
	}

	return true
}

function areSelectedFiltersEqual(
	left: DropdownFilterBarValue,
	right: DropdownFilterBarValue,
): boolean {
	const categoryKeys = new Set([...Object.keys(left), ...Object.keys(right)])
	for (const categoryKey of categoryKeys) {
		if (!areStringArraysEqual(left[categoryKey] ?? [], right[categoryKey] ?? [])) {
			return false
		}
	}

	return true
}

function getOptionsWithSelectedValues(
	options: DropdownFilterBarItem[],
	selectedValues: string[],
): DropdownFilterBarItem[] {
	if (selectedValues.length === 0) {
		return options
	}

	const knownValues = new Set(options.filter(isDropdownFilterOption).map((option) => option.value))
	const missingSelectedOptions = selectedValues
		.filter((value) => !knownValues.has(value))
		.map((value) => ({
			value,
			label: value,
		}))

	return missingSelectedOptions.length === 0 ? options : [...options, ...missingSelectedOptions]
}

function getCategorySyntheticValueSet(category: DropdownFilterBarCategory): Set<string> {
	return new Set((category.syntheticOptions ?? []).map((option) => option.value))
}

function getCategorySyntheticValues(categoryKey: string): Set<string> {
	const category = filterCategoriesByKey.value.get(categoryKey)
	return category ? getCategorySyntheticValueSet(category) : new Set()
}

function getVisiblePreviewOptions(category: DropdownFilterBarCategory): MultiSelectItem<string>[] {
	return category.options.map((option) =>
		isDropdownFilterSectionHeader(option)
			? option
			: {
					value: option.value,
					label: option.label,
					searchTerms: option.searchTerms,
					disabled: option.disabled,
				},
	) as MultiSelectItem<string>[]
}

function getPreviewOptionLabel(
	category: DropdownFilterBarCategory,
	selectedValue: string,
): string | undefined {
	return [...(category.syntheticOptions ?? []), ...category.options].find(
		(option) => isDropdownFilterOption(option) && option.value === selectedValue,
	)?.label
}

function getSelectedValues(
	categoryKey: string,
	source: 'committed' | 'draft' = 'committed',
): string[] {
	if (source === 'draft') {
		return draftSelectedFilters.value[categoryKey] ?? []
	}

	return props.modelValue[categoryKey] ?? []
}

function setSelectedValues(
	categoryKey: string,
	values: string[],
	source: 'committed' | 'draft' = 'committed',
) {
	const normalizedValues = normalizeSelectedValues(values)
	const currentFilters = source === 'draft' ? draftSelectedFilters.value : props.modelValue
	if (areStringArraysEqual(currentFilters[categoryKey] ?? [], normalizedValues)) {
		return
	}

	const nextFilters = getNextSelectedFilters(currentFilters, categoryKey, normalizedValues)

	if (source === 'draft') {
		draftSelectedFilters.value = nextFilters
		if (isAddMenuOpen.value && activeCategoryKey.value === categoryKey) {
			scheduleSubmenuPositionUpdate()
		}
		if (props.applyImmediately) {
			emit('update:modelValue', nextFilters)
		}
	} else {
		emit('update:modelValue', nextFilters)
	}
}

function setActiveCategorySelectedValues(values: string[]) {
	if (!activeCategory.value) {
		return
	}

	setSelectedValues(activeCategory.value.key, values, 'draft')
}

function resetAddMenuDraft() {
	draftSelectedFilters.value = cloneSelectedFilters(props.modelValue)
}

function commitAddMenuDraft() {
	if (!areSelectedFiltersEqual(props.modelValue, draftSelectedFilters.value)) {
		emit('update:modelValue', cloneSelectedFilters(draftSelectedFilters.value))
	}
}

function syncMobileAddMenuLayout(): boolean {
	if (typeof window === 'undefined') {
		return false
	}

	const nextValue = window.matchMedia(MOBILE_ADD_MENU_LAYOUT_QUERY).matches
	if (nextValue === isMobileAddMenuLayout.value) {
		return false
	}

	isMobileAddMenuLayout.value = nextValue
	return true
}

function openAddMenu() {
	if (isAddMenuOpen.value) {
		return
	}

	dismissTooltip()
	commitPreviewFilterDrafts()
	resetAddMenuDraft()
	syncMobileAddMenuLayout()
	isAddMenuOpen.value = true
}

function closeAddMenu() {
	if (!isAddMenuOpen.value) {
		return
	}

	commitAddMenuDraft()
	categorySearchQuery.value = ''
	isAddMenuOpen.value = false
}

function returnToCategoryMenu() {
	activeCategoryKey.value = null
	categorySearchQuery.value = ''
	hasSubmenuPosition.value = false
	nextTick(() => scheduleAddMenuPositionUpdate())
}

function handleAddMenuTriggerClick(event: MouseEvent) {
	if (event.detail === 0) {
		return
	}

	if (isAddMenuOpen.value) {
		closeAddMenu()
	} else {
		openAddMenu()
	}
}

function handleAddMenuTriggerKeydown(event: KeyboardEvent) {
	switch (event.key) {
		case 'Enter':
		case ' ':
		case 'ArrowDown':
			event.preventDefault()
			openAddMenu()
			break
		case 'Escape':
			event.preventDefault()
			closeAddMenu()
			break
	}
}

function handleAddMenuKeydown(event: KeyboardEvent) {
	if (event.key !== 'Escape') {
		return
	}

	event.preventDefault()
	closeAddMenu()
	nextTick(() => addMenuTriggerElement.value?.focus())
}

function setCategoryButtonRef(
	categoryKey: string,
	element: Element | ComponentPublicInstance | null,
) {
	if (element instanceof HTMLElement) {
		categoryButtonRefs.set(categoryKey, element)
		if (isAddMenuOpen.value && categoryKey === activeCategoryKey.value) {
			scheduleSubmenuPositionUpdate()
		}
	} else {
		categoryButtonRefs.delete(categoryKey)
	}
}

function isFilterValueSelected(categoryKey: string, value: string): boolean {
	if (categoryKey === activeCategory.value?.key) {
		return activeCategorySelectedValueSet.value.has(value)
	}

	return getSelectedValues(categoryKey, 'draft').includes(value)
}

function toggleFilterValue(categoryKey: string, value: string, nextValue: boolean) {
	const currentValues = getSelectedValues(categoryKey, 'draft')

	if (nextValue) {
		const syntheticValues = getCategorySyntheticValues(categoryKey)
		const nextValues = syntheticValues.has(value)
			? [value]
			: currentValues.filter((item) => !syntheticValues.has(item))

		if (!nextValues.includes(value)) {
			setSelectedValues(categoryKey, [...nextValues, value], 'draft')
		}
	} else {
		setSelectedValues(
			categoryKey,
			currentValues.filter((item) => item !== value),
			'draft',
		)
	}
}

function toggleFilterOption(categoryKey: string, option: DropdownFilterBarOption) {
	if (option.disabled) {
		return
	}

	toggleFilterValue(categoryKey, option.value, !isFilterValueSelected(categoryKey, option.value))
}

function getActiveCategoryItemKey(item: RenderedDropdownFilterBarItem, index: number) {
	return isDropdownFilterSectionHeader(item)
		? (item.key ?? `${activeCategory.value?.key ?? 'category'}-section-${item.label}-${index}`)
		: `${activeCategory.value?.key ?? 'category'}-${item.value}`
}

function getSectionHeaderOptions(sectionHeader: DropdownFilterBarSectionHeader) {
	const category = activeCategory.value
	if (!category) {
		return []
	}

	const sectionHeaderIndex = category.options.findIndex((item) => item === sectionHeader)
	if (sectionHeaderIndex === -1) {
		return []
	}

	const options: DropdownFilterBarOption[] = []
	for (let index = sectionHeaderIndex + 1; index < category.options.length; index += 1) {
		const item = category.options[index]
		if (!item || isDropdownFilterSectionHeader(item)) {
			break
		}
		if (!item.disabled) {
			options.push(item)
		}
	}

	return options
}

function hasSelectableSectionHeaderOptions(sectionHeader: DropdownFilterBarSectionHeader) {
	return getSectionHeaderOptions(sectionHeader).length > 1
}

function areSectionHeaderOptionsSelected(sectionHeader: DropdownFilterBarSectionHeader) {
	const options = getSectionHeaderOptions(sectionHeader)
	return (
		options.length > 0 &&
		options.every((option) => activeCategorySelectedValueSet.value.has(option.value))
	)
}

function toggleSectionHeaderOptions(sectionHeader: DropdownFilterBarSectionHeader) {
	const category = activeCategory.value
	if (!category) {
		return
	}

	const options = getSectionHeaderOptions(sectionHeader)
	if (options.length === 0) {
		return
	}

	const optionValues = options.map((option) => option.value)
	const optionValueSet = new Set(optionValues)
	const currentValues = activeCategorySelectedValues.value
	const nextValues = areSectionHeaderOptionsSelected(sectionHeader)
		? currentValues.filter((value) => !optionValueSet.has(value))
		: [...currentValues, ...optionValues.filter((value) => !currentValues.includes(value))]

	setSelectedValues(category.key, nextValues, 'draft')
}

function getActiveCategoryOptionWrapperStyle(index: number): CSSProperties | undefined {
	if (!shouldVirtualizeActiveCategoryOptions.value) {
		return undefined
	}

	return {
		transform: `translateY(${index * DROPDOWN_FILTER_OPTION_ROW_HEIGHT}px)`,
	}
}

async function initializeActiveCategoryOptionsOverlayScrollbars() {
	await nextTick()
	syncActiveCategoryOptionsVirtualScrollState()

	if (!isAddMenuOpen.value || filteredActiveCategoryOptions.value.length === 0) {
		destroyActiveCategoryOptionsOverlayScrollbars()
		return
	}

	if (
		!activeCategoryOptionsScrollbar.value ||
		!activeCategoryOptionsContainer.value ||
		!activeCategoryOptionsListContainer.value
	) {
		return
	}

	if (activeCategoryOptionsOverlayScrollbars.value) {
		activeCategoryOptionsOverlayScrollbars.value.update(true)
		return
	}

	activeCategoryOptionsOverlayScrollbars.value = OverlayScrollbars(
		{
			target: activeCategoryOptionsScrollbar.value,
			elements: {
				viewport: activeCategoryOptionsContainer.value,
				content: activeCategoryOptionsListContainer.value,
			},
		},
		OPTIONS_OVERLAY_SCROLLBARS_OPTIONS,
	)
}

function destroyActiveCategoryOptionsOverlayScrollbars() {
	activeCategoryOptionsOverlayScrollbars.value?.destroy()
	activeCategoryOptionsOverlayScrollbars.value = null
}

function resetActiveCategoryOptionsScrollState() {
	if (activeCategoryOptionsContainer.value) {
		activeCategoryOptionsContainer.value.scrollTop = 0
	}
	resetActiveCategoryOptionsVirtualScrollState()
}

function getCategorySelectionCount(
	categoryKey: string,
	source: 'committed' | 'draft' = 'committed',
): number {
	return getSelectedValues(categoryKey, source).length
}

function getNextSelectedFilters(
	currentFilters: DropdownFilterBarValue,
	categoryKey: string,
	selectedValues: string[],
): DropdownFilterBarValue {
	const nextFilters = cloneSelectedFilters(currentFilters)

	nextFilters[categoryKey] = selectedValues
	return nextFilters
}

function getCategorySelectionSummary(category: DropdownFilterBarCategory): string {
	const count = getCategorySelectionCount(category.key)
	if (count === 0) {
		return ''
	}

	if (count === 1) {
		const selectedValue = getSelectedValues(category.key)[0]
		return getPreviewOptionLabel(category, selectedValue) ?? '1 selected'
	}

	return `${count} selected`
}

function clearFilterCategory(categoryKey: string) {
	commitPreviewFilterDrafts()
	setSelectedValues(categoryKey, [])
}

function clearAllFilters() {
	commitPreviewFilterDrafts()

	const nextFilters = cloneSelectedFilters(props.modelValue)
	for (const category of filterCategories.value) {
		nextFilters[category.key] = []
	}

	if (!areSelectedFiltersEqual(props.modelValue, nextFilters)) {
		emit('update:modelValue', nextFilters)
	}

	emit('clear')
}

function clearActiveCategorySelection() {
	if (!activeCategory.value) {
		return
	}

	setSelectedValues(activeCategory.value.key, [], 'draft')
}

function getPreviewSelectedValues(categoryKey: string): string[] {
	const draftValues = previewSelectedValueDrafts.value[categoryKey]
	if (draftValues !== undefined) {
		return draftValues
	}

	return getSelectedValues(categoryKey)
}

function setPreviewSelectedValues(categoryKey: string, values: string[]) {
	const normalizedValues = normalizeSelectedValues(values)
	previewSelectedValueDrafts.value = {
		...previewSelectedValueDrafts.value,
		[categoryKey]: normalizedValues,
	}
	if (props.applyImmediately) {
		setSelectedValues(categoryKey, normalizedValues)
	}
}

function openPreviewFilterDraft(categoryKey: string) {
	commitPreviewFilterDrafts()
	previewSelectedValueDrafts.value = {
		...previewSelectedValueDrafts.value,
		[categoryKey]: [...getSelectedValues(categoryKey)],
	}
}

function commitPreviewFilterDraft(categoryKey: string) {
	const draftValues = previewSelectedValueDrafts.value[categoryKey]
	if (draftValues === undefined) {
		return
	}

	previewSelectedValueDrafts.value = Object.fromEntries(
		Object.entries(previewSelectedValueDrafts.value).filter(([key]) => key !== categoryKey),
	)
	setSelectedValues(categoryKey, draftValues)
}

function commitPreviewFilterDrafts() {
	for (const categoryKey of Object.keys(previewSelectedValueDrafts.value)) {
		commitPreviewFilterDraft(categoryKey)
	}
}

function closePreviewFilterMenu(categoryKey: string, event?: Event) {
	commitPreviewFilterDraft(categoryKey)

	const eventTarget = event?.target
	if (!(eventTarget instanceof HTMLElement)) {
		return
	}

	const dropdown = eventTarget.closest('[role="listbox"][aria-multiselectable="true"]')
	if (!dropdown) {
		return
	}

	dropdown.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
}

function getPreviewDropdownWidth(category: DropdownFilterBarCategory): string | number | undefined {
	return category.previewDropdownWidth ?? getWidthFromClass(category.submenuClass)
}

function getPreviewDropdownMinWidth(category: DropdownFilterBarCategory): string | number {
	return (
		category.previewDropdownMinWidth ??
		getPreviewDropdownWidth(category) ??
		DEFAULT_PREVIEW_DROPDOWN_MIN_WIDTH
	)
}

function getWidthFromClass(className: string | undefined): string | undefined {
	if (!className) {
		return undefined
	}

	const arbitraryWidth = className.match(/(?:^|\s)w-\[([^\]]+)\](?:\s|$)/)
	if (arbitraryWidth) {
		return arbitraryWidth[1]
	}

	return className
		.split(/\s+/)
		.map((name) => TAILWIND_WIDTH_CLASS_SIZE[name])
		.find((width) => width !== undefined)
}

function getRootFontSizeInPixels(): number {
	if (typeof window === 'undefined') {
		return DEFAULT_ROOT_FONT_SIZE
	}

	const rootFontSize = Number.parseFloat(window.getComputedStyle(document.documentElement).fontSize)
	return Number.isFinite(rootFontSize) ? rootFontSize : DEFAULT_ROOT_FONT_SIZE
}

function getCssLengthInPixels(length: string): number | undefined {
	const trimmedLength = length.trim()
	const parsedLength = Number.parseFloat(trimmedLength)
	if (!Number.isFinite(parsedLength)) {
		return undefined
	}

	if (trimmedLength.endsWith('rem')) {
		return parsedLength * getRootFontSizeInPixels()
	}

	if (trimmedLength.endsWith('px') || /^[\d.]+$/.test(trimmedLength)) {
		return parsedLength
	}

	return undefined
}

function getSubmenuWidthInPixels(category: DropdownFilterBarCategory): number {
	return (
		getCssLengthInPixels(getWidthFromClass(category.submenuClass) ?? DEFAULT_SUBMENU_WIDTH) ??
		getCssLengthInPixels(DEFAULT_SUBMENU_WIDTH) ??
		288
	)
}

function getWidestSubmenuWidthInPixels(categories: DropdownFilterBarCategory[]): number {
	return Math.max(
		...categories
			.filter((category) => !category.direct)
			.map((category) => getSubmenuWidthInPixels(category)),
		0,
	)
}

function getDirectCategoryOption(category: DropdownFilterBarCategory) {
	if (!category.direct) return undefined
	return category.options.find(isDropdownFilterOption)
}

function isDirectCategorySelected(category: DropdownFilterBarCategory) {
	const option = getDirectCategoryOption(category)
	return !!option && isFilterValueSelected(category.key, option.value)
}

function deactivateCategory() {
	clearPendingCategoryTimeout()
	pendingCategoryKey.value = null
	activeCategoryKey.value = null
	categorySearchQuery.value = ''
	hasSubmenuPosition.value = false
}

function handleCategoryClick(category: DropdownFilterBarCategory) {
	const option = getDirectCategoryOption(category)
	if (!option) {
		activateCategory(category.key)
		return
	}

	deactivateCategory()
	toggleFilterOption(category.key, option)
	scheduleAddMenuPositionUpdate()
}

function activateCategory(categoryKey: string) {
	clearPendingCategoryTimeout()
	pendingCategoryKey.value = null
	if (activeCategoryKey.value !== categoryKey) {
		categorySearchQuery.value = ''
	}
	activeCategoryKey.value = categoryKey
	scheduleSubmenuPositionUpdate()
	if (isMobileAddMenuLayout.value) {
		scheduleAddMenuPositionUpdate()
	}
}

function handleCategoryFocus(category: DropdownFilterBarCategory) {
	if (category.direct) {
		deactivateCategory()
		return
	}
	if (isMobileAddMenuLayout.value) {
		return
	}

	activateCategory(category.key)
}

function handleCategoryMouseEnter(category: DropdownFilterBarCategory) {
	if (category.direct) {
		deactivateCategory()
		return
	}
	if (isMobileAddMenuLayout.value) {
		return
	}
	const categoryKey = category.key

	if (!activeCategoryKey.value) {
		activateCategory(categoryKey)
		return
	}

	if (categoryKey === activeCategoryKey.value) {
		clearPendingCategoryTimeout()
		pendingCategoryKey.value = null
		return
	}

	if (!isCursorAimingAtSubmenu(lastMousePosition.value, previousMousePosition)) {
		activateCategory(categoryKey)
		return
	}

	pendingCategoryKey.value = categoryKey
	clearPendingCategoryTimeout()
	pendingCategoryTimeout = setTimeout(() => {
		if (pendingCategoryKey.value !== categoryKey) {
			return
		}

		if (
			isCursorInsideSubmenu.value ||
			isCursorAimingAtSubmenu(lastMousePosition.value, previousMousePosition)
		) {
			pendingCategoryKey.value = null
			return
		}

		activateCategory(categoryKey)
	}, 180)
}

function handleMenuMouseMove(event: MouseEvent, source: 'menu' | 'submenu') {
	previousMousePosition = lastMousePosition.value
	lastMousePosition.value = {
		x: event.clientX,
		y: event.clientY,
	}

	if (source !== 'menu') {
		return
	}

	if (
		!pendingCategoryKey.value ||
		isCursorAimingAtSubmenu(lastMousePosition.value, previousMousePosition)
	) {
		return
	}

	activateCategory(pendingCategoryKey.value)
}

function isCursorAimingAtSubmenu(cursor: Point | null, origin: Point | null): boolean {
	return getIsCursorAimingAtSubmenu(cursor, origin, submenu.value?.getBoundingClientRect() ?? null)
}

function clearPendingCategoryTimeout() {
	if (pendingCategoryTimeout) {
		clearTimeout(pendingCategoryTimeout)
		pendingCategoryTimeout = null
	}
}

function getViewportRect(): ViewportRect {
	const visualViewport = window.visualViewport

	return {
		width: visualViewport?.width ?? window.innerWidth,
		height: visualViewport?.height ?? window.innerHeight,
		offsetTop: visualViewport?.offsetTop ?? 0,
		offsetLeft: visualViewport?.offsetLeft ?? 0,
	}
}

function getAddMenuPosition({
	triggerRect,
	dropdownRect,
	dropdownHeight,
	viewport,
}: MenuPositionOptions) {
	const dropdownWidth = Math.max(ADD_MENU_WIDTH, triggerRect.width)
	const positionedDropdownWidth = Math.max(dropdownRect.width, dropdownWidth)
	const triggerTop = triggerRect.top + viewport.offsetTop
	const triggerBottom = triggerRect.bottom + viewport.offsetTop
	const triggerLeft = triggerRect.left + viewport.offsetLeft
	const viewportTop = viewport.offsetTop
	const viewportBottom = viewport.offsetTop + viewport.height
	const viewportLeft = viewport.offsetLeft
	const viewportRight = viewport.offsetLeft + viewport.width
	const minLeft = viewportLeft + DROPDOWN_VIEWPORT_MARGIN
	const maxLeft = Math.max(
		minLeft,
		viewportRight - positionedDropdownWidth - DROPDOWN_VIEWPORT_MARGIN,
	)
	const spaceBelow = Math.max(
		0,
		viewportBottom - triggerBottom - DROPDOWN_GAP - DROPDOWN_VIEWPORT_MARGIN,
	)
	const spaceAbove = Math.max(0, triggerTop - viewportTop - DROPDOWN_GAP - DROPDOWN_VIEWPORT_MARGIN)
	const hasSpaceBelow = dropdownHeight <= spaceBelow
	const hasSpaceAbove = dropdownHeight <= spaceAbove
	const opensUp = !hasSpaceBelow && (hasSpaceAbove || spaceAbove > spaceBelow)
	const availableHeight = opensUp ? spaceAbove : spaceBelow
	const positionedDropdownHeight = Math.min(dropdownHeight, availableHeight)
	const top = opensUp
		? triggerTop - positionedDropdownHeight - DROPDOWN_GAP
		: triggerBottom + DROPDOWN_GAP
	const left = Math.min(Math.max(minLeft, triggerLeft), maxLeft)

	return {
		left: `${left}px`,
		maxHeight: `${availableHeight}px`,
		minWidth: `${triggerRect.width}px`,
		top: `${Math.max(viewportTop + DROPDOWN_VIEWPORT_MARGIN, top)}px`,
		width: `${dropdownWidth}px`,
	}
}

function getSubmenuPosition({
	buttonRect,
	openDirection,
	submenuWidth,
	submenuHeight,
	viewport,
}: SubmenuPositionOptions): Point {
	const buttonTop = buttonRect.top + viewport.offsetTop
	const buttonLeft = buttonRect.left + viewport.offsetLeft
	const buttonRight = buttonRect.right + viewport.offsetLeft
	const viewportTop = viewport.offsetTop
	const viewportBottom = viewport.offsetTop + viewport.height
	const viewportLeft = viewport.offsetLeft
	const viewportRight = viewport.offsetLeft + viewport.width
	const minLeft = viewportLeft + DROPDOWN_VIEWPORT_MARGIN
	const preferredLeft =
		openDirection === 'right'
			? buttonRight + DROPDOWN_GAP
			: buttonLeft - submenuWidth - DROPDOWN_GAP
	const maxLeft = Math.max(minLeft, viewportRight - submenuWidth - DROPDOWN_VIEWPORT_MARGIN)
	const left = Math.min(Math.max(minLeft, preferredLeft), maxLeft)
	const minTop = viewportTop + DROPDOWN_VIEWPORT_MARGIN
	const top = Math.min(
		Math.max(minTop, buttonTop),
		Math.max(minTop, viewportBottom - submenuHeight - DROPDOWN_VIEWPORT_MARGIN),
	)

	return {
		x: left,
		y: top,
	}
}

function getSubmenuOpenDirection({
	menuRect,
	widestSubmenuWidth,
	viewport,
}: SubmenuOpenDirectionOptions): SubmenuOpenDirection {
	const menuLeft = menuRect.left + viewport.offsetLeft
	const menuRight = menuRect.right + viewport.offsetLeft
	const viewportLeft = viewport.offsetLeft
	const viewportRight = viewport.offsetLeft + viewport.width
	const rightSpace = viewportRight - menuRight - DROPDOWN_GAP - DROPDOWN_VIEWPORT_MARGIN
	const leftSpace = menuLeft - viewportLeft - DROPDOWN_GAP - DROPDOWN_VIEWPORT_MARGIN

	if (rightSpace >= widestSubmenuWidth) {
		return 'right'
	}

	if (leftSpace >= widestSubmenuWidth) {
		return 'left'
	}

	return rightSpace >= leftSpace ? 'right' : 'left'
}

function getIsCursorAimingAtSubmenu(
	cursor: Point | null,
	origin: Point | null,
	submenuRect: DOMRect | null,
): boolean {
	if (!submenuRect || !cursor || !origin) {
		return false
	}

	const submenuTargetX =
		origin.x <= submenuRect.left
			? submenuRect.left
			: origin.x >= submenuRect.right
				? submenuRect.right
				: cursor.x <= submenuRect.left
					? submenuRect.left
					: submenuRect.right
	const upperTarget: Point = {
		x: submenuTargetX,
		y: submenuRect.top + 20,
	}
	const lowerTarget: Point = {
		x: submenuTargetX,
		y: submenuRect.bottom + 20,
	}

	return isPointInTriangle(cursor, origin, upperTarget, lowerTarget)
}

function isPointInTriangle(point: Point, a: Point, b: Point, c: Point): boolean {
	const area = triangleArea(a, b, c)
	const area1 = triangleArea(point, b, c)
	const area2 = triangleArea(a, point, c)
	const area3 = triangleArea(a, b, point)

	return Math.abs(area - (area1 + area2 + area3)) < 0.5
}

function triangleArea(a: Point, b: Point, c: Point): number {
	return Math.abs((a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y)) / 2)
}

function updateAddMenuPosition(): boolean {
	const positioningElement =
		menuContainer.value ?? (isMobileActiveSubmenu.value ? submenu.value : null)
	const triggerElement = addMenuTriggerElement.value
	if (typeof window === 'undefined' || !triggerElement || !positioningElement) {
		return false
	}

	const triggerRect = triggerElement.getBoundingClientRect()
	const dropdownWidth = Math.max(ADD_MENU_WIDTH, triggerRect.width)

	addMenuStyle.value = {
		...addMenuStyle.value,
		minWidth: `${triggerRect.width}px`,
		width: `${dropdownWidth}px`,
	}

	const dropdownRect = positioningElement.getBoundingClientRect()
	const viewport = getViewportRect()
	addMenuStyle.value = getAddMenuPosition({
		triggerRect,
		dropdownRect,
		dropdownHeight: positioningElement.scrollHeight,
		viewport,
	})
	return true
}

function updateSubmenuOpenDirection(): boolean {
	if (typeof window === 'undefined' || !menuContainer.value) {
		return false
	}

	submenuOpenDirection.value = getSubmenuOpenDirection({
		menuRect: menuContainer.value.getBoundingClientRect(),
		widestSubmenuWidth: getWidestSubmenuWidthInPixels(filterCategories.value),
		viewport: getViewportRect(),
	})
	return true
}

function scheduleAddMenuPositionUpdate(retries = 8) {
	if (typeof window === 'undefined') {
		return
	}

	nextTick(() => {
		if (!isAddMenuOpen.value) {
			return
		}

		if (updateAddMenuPosition()) {
			if (!isMobileAddMenuLayout.value) {
				updateSubmenuOpenDirection()
			}
			return
		}

		if (retries <= 0) {
			return
		}

		setTimeout(() => scheduleAddMenuPositionUpdate(retries - 1), 0)
	})
}

function updateSubmenuPosition(): boolean {
	if (typeof window === 'undefined') {
		return false
	}

	if (!activeCategoryKey.value) {
		return false
	}

	if (isMobileAddMenuLayout.value) {
		hasSubmenuPosition.value = true
		return true
	}

	const activeButton = categoryButtonRefs.get(activeCategoryKey.value)
	if (!activeButton) {
		return false
	}

	const buttonRect = activeButton.getBoundingClientRect()
	const submenuRect = submenu.value?.getBoundingClientRect()
	const submenuWidth =
		submenuRect?.width ??
		(activeCategory.value ? getSubmenuWidthInPixels(activeCategory.value) : 256)
	const submenuHeight = submenuRect?.height ?? 320

	updateSubmenuOpenDirection()
	const viewport = getViewportRect()
	submenuPosition.value = getSubmenuPosition({
		buttonRect,
		openDirection: submenuOpenDirection.value,
		submenuWidth,
		submenuHeight,
		viewport,
	})
	hasSubmenuPosition.value = true
	return true
}

function scheduleSubmenuPositionUpdate(retries = 8) {
	if (typeof window === 'undefined') {
		return
	}

	nextTick(() => {
		if (!isAddMenuOpen.value) {
			return
		}

		const hasRenderedSubmenu = submenu.value !== null
		if (updateSubmenuPosition()) {
			if (!hasRenderedSubmenu) {
				nextTick(() => updateSubmenuPosition())
			}
			return
		}

		if (retries <= 0) {
			return
		}

		setTimeout(() => scheduleSubmenuPositionUpdate(retries - 1), 0)
	})
}

function resetPendingCategory() {
	clearPendingCategoryTimeout()
	pendingCategoryKey.value = null
	isCursorInsideSubmenu.value = false
	lastMousePosition.value = null
	previousMousePosition = null
}

function handleSubmenuMouseEnter() {
	isCursorInsideSubmenu.value = true
	clearPendingCategoryTimeout()
	pendingCategoryKey.value = null
}

function handleSubmenuMouseLeave() {
	isCursorInsideSubmenu.value = false
}

function updateMenuPositions() {
	if (!isAddMenuOpen.value) {
		return
	}

	if (syncMobileAddMenuLayout()) {
		scheduleAddMenuPositionUpdate()
		scheduleSubmenuPositionUpdate()
		return
	}

	updateAddMenuPosition()
	if (!isMobileAddMenuLayout.value) {
		updateSubmenuOpenDirection()
	}
	updateSubmenuPosition()
}

function scheduleMenuPositionsUpdate() {
	if (typeof window === 'undefined' || addMenuPositionRafId !== null) {
		return
	}

	addMenuPositionRafId = window.requestAnimationFrame(() => {
		addMenuPositionRafId = null
		updateMenuPositions()
	})
}

function handleViewportChange() {
	scheduleMenuPositionsUpdate()
}

function startAddMenuPositionTracking() {
	if (typeof window === 'undefined') {
		return
	}

	window.addEventListener('resize', handleViewportChange)
	window.addEventListener('scroll', handleViewportChange, true)
	window.visualViewport?.addEventListener('scroll', handleViewportChange)
	window.visualViewport?.addEventListener('resize', handleViewportChange)
}

function stopAddMenuPositionTracking() {
	if (typeof window === 'undefined') {
		return
	}

	window.removeEventListener('resize', handleViewportChange)
	window.removeEventListener('scroll', handleViewportChange, true)
	window.visualViewport?.removeEventListener('scroll', handleViewportChange)
	window.visualViewport?.removeEventListener('resize', handleViewportChange)

	if (addMenuPositionRafId !== null) {
		window.cancelAnimationFrame(addMenuPositionRafId)
		addMenuPositionRafId = null
	}
}

onClickOutside(
	addMenuOutsideClickTarget,
	() => {
		closeAddMenu()
	},
	{ ignore: addMenuOutsideClickIgnore },
)

watch(isAddMenuOpen, (isOpen) => {
	if (isOpen) {
		activeCategoryKey.value = null
		hasSubmenuPosition.value = false
		scheduleAddMenuPositionUpdate()
		startAddMenuPositionTracking()
	} else {
		activeCategoryKey.value = null
		hasSubmenuPosition.value = false
		resetPendingCategory()
		resetActiveCategoryOptionsScrollState()
		stopAddMenuPositionTracking()
		destroyActiveCategoryOptionsOverlayScrollbars()
	}
})

watch(categorySearchQuery, () => {
	activeCategory.value?.onSearchQueryChange?.(categorySearchQuery.value)
	resetActiveCategoryOptionsScrollState()
	initializeActiveCategoryOptionsOverlayScrollbars()
	scheduleSubmenuPositionUpdate()
})

watch(activeCategoryKey, (categoryKey) => {
	resetActiveCategoryOptionsScrollState()
	if (categoryKey) {
		activeCategory.value?.onSearchQueryChange?.(categorySearchQuery.value)
		initializeActiveCategoryOptionsOverlayScrollbars()
	} else {
		destroyActiveCategoryOptionsOverlayScrollbars()
	}
})

watch(filteredActiveCategoryOptions, () => {
	if (!isAddMenuOpen.value) {
		return
	}

	if (filteredActiveCategoryOptions.value.length > 0) {
		initializeActiveCategoryOptionsOverlayScrollbars()
	} else {
		destroyActiveCategoryOptionsOverlayScrollbars()
	}
	scheduleSubmenuPositionUpdate()
})

watch(filterCategoriesByKey, (nextCategories) => {
	if (activeCategoryKey.value && !nextCategories.has(activeCategoryKey.value)) {
		activeCategoryKey.value = null
		hasSubmenuPosition.value = false
	}

	if (isAddMenuOpen.value) {
		updateSubmenuOpenDirection()
		scheduleSubmenuPositionUpdate()
	}
})

watch(
	() => props.modelValue,
	() => {
		if (!isAddMenuOpen.value) {
			draftSelectedFilters.value = cloneSelectedFilters(props.modelValue)
		}
	},
	{ deep: true },
)

onMounted(() => {
	isClient.value = true
})

onBeforeUnmount(() => {
	clearPendingCategoryTimeout()
	stopAddMenuPositionTracking()
	destroyActiveCategoryOptionsOverlayScrollbars()
	if (isAddMenuOpen.value) {
		commitAddMenuDraft()
	}
	commitPreviewFilterDrafts()
})
</script>

<style lang="scss" scoped>
.checkbox-shadow {
	box-shadow: 1px 1px 2px 0 rgba(0, 0, 0, 0.08);
}

.dropdown-filter-bar-options-scrollbar :deep(.os-theme-modrinth) {
	--os-size: 8px;
	--os-padding-perpendicular: 0px;
	--os-padding-axis: 0px;
	--os-track-bg: transparent;
	--os-track-bg-hover: transparent;
	--os-track-bg-active: transparent;
	--os-handle-border-radius: 9999px;
	--os-handle-border: 2px solid var(--color-surface-4);
	--os-handle-border-hover: 2px solid var(--color-surface-4);
	--os-handle-border-active: 2px solid var(--color-surface-4);
	--os-handle-bg: var(--color-scrollbar, var(--color-surface-5));
	--os-handle-bg-hover: var(--color-scrollbar, var(--color-surface-5));
	--os-handle-bg-active: var(--color-scrollbar, var(--color-surface-5));
}
</style>
