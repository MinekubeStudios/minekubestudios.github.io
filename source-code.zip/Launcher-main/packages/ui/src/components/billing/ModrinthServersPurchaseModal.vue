<script setup lang="ts">
import { type Archon, type Labrinth, pingWebSocketUrl } from '@modrinth/api-client'
import {
	CheckCircleIcon,
	ChevronRightIcon,
	LeftArrowIcon,
	RightArrowIcon,
	SpinnerIcon,
	XIcon,
} from '@modrinth/assets'
import { useQueryClient } from '@tanstack/vue-query'
import type Stripe from 'stripe'
import { computed, nextTick, onBeforeUnmount, ref, toRef, useTemplateRef, watch } from 'vue'

import { Button } from '#ui/components/base/buttons'
import { injectNotificationManager } from '#ui/providers/web-notifications.ts'

import { useDebugLogger } from '../../composables/debug-logger'
import { defineMessage, type MessageDescriptor, useVIntl } from '../../composables/i18n'
import { useStripe } from '../../composables/stripe'
import { commonMessages } from '../../utils'
import ModalLoadingIndicator from '../modal/ModalLoadingIndicator.vue'
import NewModal from '../modal/NewModal.vue'
import PlanSelector from './ServersPurchase0Plan.vue'
import RegionSelector from './ServersPurchase1Region.vue'
import PaymentMethodSelector from './ServersPurchase2PaymentMethod.vue'
import ConfirmPurchase from './ServersPurchase3Review.vue'

const { formatMessage } = useVIntl()
const { addNotification } = injectNotificationManager()
const queryClient = useQueryClient()
const debug = useDebugLogger('ModrinthServersPurchaseModal')

export type RegionPing = {
	region: string
	ping: number
}

// Type alias for billing interval that matches both the local and api-client types
export type ServerBillingInterval = 'monthly' | 'quarterly' | 'yearly'

const props = defineProps<{
	publishableKey: string
	returnUrl?: string
	paymentMethods: Stripe.PaymentMethod[]
	customer: Stripe.Customer
	currency: string
	regions: Archon.Servers.v1.Region[]
	availableProducts: Labrinth.Billing.Internal.Product[]
	planStage?: boolean
	existingPlan?: Labrinth.Billing.Internal.Product
	existingSubscription?: Labrinth.Billing.Internal.UserSubscription
	refreshPaymentMethods: () => Promise<void>
	fetchStock: (
		region: Archon.Servers.v1.Region,
		request: Archon.Servers.v0.StockRequest,
	) => Promise<number>
	initiatePayment: (
		body: Labrinth.Billing.Internal.InitiatePaymentRequest,
	) => Promise<
		| Labrinth.Billing.Internal.InitiatePaymentResponse
		| Labrinth.Billing.Internal.EditSubscriptionResponse
		| null
	>
	onError: (err: Error) => void
	onFinalizeNoPaymentChange?: () => Promise<void>
	affiliateCode?: string | null
}>()

const modal = useTemplateRef<InstanceType<typeof NewModal>>('modal')
const selectedPlan = ref<Labrinth.Billing.Internal.Product>()
const selectedInterval = ref<ServerBillingInterval>('quarterly')
const loading = ref(false)
const selectedRegion = ref<string>()
const projectId = ref<string>()
const affiliateCode = ref(props.affiliateCode ?? null)

const {
	initializeStripe,
	selectPaymentMethod,
	primaryPaymentMethodId,
	loadStripeElements,
	selectedPaymentMethod,
	inputtedPaymentMethod,
	createNewPaymentMethod,
	loadingElements,
	loadingElementsFailed,
	tax,
	total,
	paymentMethodLoading,
	reloadPaymentIntent,
	hasPaymentMethod,
	submitPayment,
	completingPurchase,
	noPaymentRequired,
} = useStripe(
	props.publishableKey,
	toRef(props, 'customer'),
	toRef(props, 'paymentMethods'),
	props.currency,
	selectedPlan,
	selectedInterval,
	selectedRegion,
	projectId,
	props.initiatePayment,
	props.onError,
	affiliateCode,
)

const customServer = ref<boolean>(false)
const acceptedEula = ref<boolean>(false)
const skipPaymentMethods = ref<boolean>(true)

type Step = 'plan' | 'region' | 'payment' | 'review'

const steps: Step[] = props.planStage
	? (['plan', 'region', 'payment', 'review'] as Step[])
	: (['region', 'payment', 'review'] as Step[])

const isUpgrade = computed(() => !!props.existingSubscription)
const existingSubscriptionRegion = computed(() =>
	props.existingSubscription?.metadata?.type === 'pyro'
		? props.existingSubscription.metadata.region
		: undefined,
)
const hideRegionSelection = computed(() => isUpgrade.value && !!existingSubscriptionRegion.value)
const skipRegionStep = computed(() => !customServer.value && hideRegionSelection.value)
const visibleSteps = computed(() => steps.filter((s) => !(s === 'region' && skipRegionStep.value)))

const titles: Record<Step, MessageDescriptor> = {
	plan: defineMessage({ id: 'servers.purchase.step.plan.title', defaultMessage: 'Plan' }),
	region: defineMessage({ id: 'servers.purchase.step.region.title', defaultMessage: 'Region' }),
	payment: defineMessage({
		id: 'servers.purchase.step.payment.title',
		defaultMessage: 'Payment method',
	}),
	review: defineMessage({ id: 'servers.purchase.step.review.title', defaultMessage: 'Review' }),
}

const purchaseSuccessTitle = defineMessage({
	id: 'servers.purchase.notification.success.title',
	defaultMessage: 'Purchase success',
})

const purchaseSuccessText = defineMessage({
	id: 'servers.purchase.notification.success.text',
	defaultMessage: 'Your Modrinth Hosting purchase was completed successfully.',
})

const currentRegion = computed(() => {
	return props.regions.find((region) => region.shortcode === selectedRegion.value)
})

const regionPings = ref<RegionPing[]>([])

const currentPing = computed(() => {
	return regionPings.value.find((ping) => ping.region === currentRegion.value?.shortcode)?.ping
})

const currentStep = ref<Step>()

const PING_COUNT = 5
const PING_INTERVAL = 200
const MAX_PING_TIME = 1000

const initialIndex: Record<string, number> = {
	'eu-lim': 31,
}

let regionPingAbortController: AbortController | null = null

function setRegionPing(region: Archon.Servers.v1.Region, ping: number) {
	regionPings.value = regionPings.value.filter((entry) => entry.region !== region.shortcode)
	regionPings.value.push({
		region: region.shortcode,
		ping,
	})
}

function stopRegionPings() {
	regionPingAbortController?.abort()
	regionPingAbortController = null
	regionPings.value = []
}

function startRegionPings() {
	regionPingAbortController?.abort()
	regionPings.value = []

	const controller = new AbortController()
	regionPingAbortController = controller

	for (const region of props.regions) {
		void runRegionPing(region, initialIndex[region.shortcode] ?? 1, controller.signal)
	}
}

function ensureRegionPings() {
	if (regionPingAbortController && !regionPingAbortController.signal.aborted) return
	startRegionPings()
}

async function runRegionPing(region: Archon.Servers.v1.Region, index: number, signal: AbortSignal) {
	if (signal.aborted) return

	const ping = await pingWebSocketUrl(`wss://${region.shortcode}${index}.${region.zone}/pingtest`, {
		count: PING_COUNT,
		intervalMs: PING_INTERVAL,
		settleDelayMs: MAX_PING_TIME,
		timeoutMs: PING_COUNT * PING_INTERVAL + MAX_PING_TIME + 1000,
		signal,
	})

	if (signal.aborted) return

	if (ping > 0) {
		setRegionPing(region, ping)
	} else {
		setRegionPing(region, -1)
	}
}

function startRegionPingsIfNeeded() {
	if (currentStep.value === 'region') {
		ensureRegionPings()
	}
}

const currentStepIndex = computed(() =>
	currentStep.value ? visibleSteps.value.indexOf(currentStep.value) : -1,
)
const previousStep = computed(() => {
	if (!currentStep.value) return undefined
	const idx = visibleSteps.value.indexOf(currentStep.value)
	let step = idx > 0 ? visibleSteps.value[idx - 1] : undefined
	if (step === 'payment' && skipPaymentMethods.value && primaryPaymentMethodId.value) {
		const paymentIdx = visibleSteps.value.indexOf('payment')
		step = paymentIdx > 0 ? visibleSteps.value[paymentIdx - 1] : undefined
	}
	return step
})
const nextStep = computed(() => {
	if (!currentStep.value) return undefined
	const idx = visibleSteps.value.indexOf(currentStep.value)
	return idx >= 0 ? visibleSteps.value[idx + 1] : undefined
})

const canProceed = computed(() => {
	switch (currentStep.value) {
		case 'plan':
			debug('Plan step:', {
				customServer: customServer.value,
				selectedPlan: selectedPlan.value,
				existingPlan: props.existingPlan,
			})
			return (
				customServer.value ||
				(!!selectedPlan.value &&
					(!props.existingPlan || selectedPlan.value.id !== props.existingPlan.id))
			)
		case 'region':
			return selectedRegion.value && selectedPlan.value && selectedInterval.value
		case 'payment':
			return selectedPaymentMethod.value || !loadingElements.value
		case 'review':
			return (
				(noPaymentRequired.value || (acceptedEula.value && hasPaymentMethod.value)) &&
				!completingPurchase.value
			)
		default:
			return false
	}
})

async function beforeProceed(step: string) {
	switch (step) {
		case 'plan':
			return true
		case 'region':
			return true
		case 'payment':
			await initializeStripe()

			if (primaryPaymentMethodId.value && skipPaymentMethods.value) {
				const paymentMethod = props.paymentMethods.find(
					(x) => x.id === primaryPaymentMethodId.value,
				)
				if (paymentMethod) {
					await selectPaymentMethod(paymentMethod)
					await setStep('review', true)
					return false
				}
			}
			return true
		case 'review':
			if (noPaymentRequired.value) {
				return true
			}
			if (selectedPaymentMethod.value) {
				return true
			} else {
				const token = await createNewPaymentMethod()
				return !!token
			}
	}
}

async function afterProceed(step: string) {
	switch (step) {
		case 'region':
			break
		case 'payment':
			await loadStripeElements()
			break
		case 'review':
			break
	}
}

async function setStep(step: Step | undefined, skipValidation = false) {
	if (!step) {
		const success = await submitPayment(props.returnUrl)

		if (success) {
			modal.value?.hide()
			addNotification({
				title: formatMessage(purchaseSuccessTitle),
				text: formatMessage(purchaseSuccessText),
				type: 'success',
			})
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: ['servers'] }),
				queryClient.invalidateQueries({ queryKey: ['servers', 'v1'] }),
			])
			emit('purchase-success')
		}

		return
	}

	if (!skipValidation && !canProceed.value) {
		return
	}

	if (await beforeProceed(step)) {
		currentStep.value = step
		startRegionPingsIfNeeded()
		await nextTick()

		await afterProceed(step)
	}
}

watch(
	selectedPlan,
	() => {
		if (currentStep.value === 'plan') {
			customServer.value = !selectedPlan.value
		}
	},
	{ flush: 'sync' },
)

watch(
	existingSubscriptionRegion,
	(region) => {
		if (region) {
			selectedRegion.value = region
		}
	},
	{ immediate: true },
)

const defaultPlan = computed<Labrinth.Billing.Internal.Product | undefined>(() => {
	return (
		props.availableProducts.find((p) => p?.metadata?.type === 'pyro' && p.metadata.ram === 6144) ??
		props.availableProducts.find((p) => p?.metadata?.type === 'pyro') ??
		props.availableProducts[0]
	)
})

function begin(
	interval: ServerBillingInterval,
	plan?: Labrinth.Billing.Internal.Product | null,
	project?: string,
) {
	loading.value = false

	if (plan === null) {
		// Explicitly open in custom mode
		selectedPlan.value = undefined
		customServer.value = true
	} else {
		selectedPlan.value = plan ?? defaultPlan.value
		customServer.value = !selectedPlan.value
	}

	selectedInterval.value = interval
	customServer.value = !selectedPlan.value
	selectedPaymentMethod.value = undefined
	const skipPlanStep = props.planStage && plan !== undefined
	currentStep.value = skipPlanStep
		? (visibleSteps.value[1] ?? visibleSteps.value[0])
		: visibleSteps.value[0]
	startRegionPingsIfNeeded()
	skipPaymentMethods.value = true
	projectId.value = project
	modal.value?.show()
}

defineExpose({
	show: begin,
})

const emit = defineEmits<{
	(e: 'hide' | 'purchase-success'): void
}>()

function handleHide() {
	stopRegionPings()
	emit('hide')
}

onBeforeUnmount(stopRegionPings)

function handleChooseCustom() {
	customServer.value = true
	selectedPlan.value = undefined
}

function handleProceed() {
	setStep(nextStep.value)
}

// When the user explicitly wants to change or add a payment method from Review
// we must disable the auto-skip behavior, clear any selected method, and
// navigate to the Payment step so Stripe Elements can mount.
async function changePaymentMethod() {
	skipPaymentMethods.value = false
	selectedPaymentMethod.value = undefined
	await setStep('payment', true)
}

function goToBreadcrumbStep(id: string) {
	if (id === 'payment') {
		return changePaymentMethod()
	}

	return setStep(id as Step, true)
}
</script>
<template>
	<NewModal ref="modal" @hide="handleHide">
		<template #title>
			<div class="flex items-center gap-1 font-bold text-secondary">
				<template v-for="(step, index) in visibleSteps" :key="step">
					<button
						v-if="index < currentStepIndex"
						class="bg-transparent active:scale-95 font-bold text-secondary p-0"
						@click="goToBreadcrumbStep(step)"
					>
						{{ formatMessage(titles[step]) }}
					</button>
					<span
						v-else
						:class="{
							'text-contrast': index === currentStepIndex,
						}"
					>
						{{ formatMessage(titles[step]) }}
					</span>
					<ChevronRightIcon
						v-if="index < visibleSteps.length - 1"
						class="h-5 w-5 text-secondary"
						stroke-width="3"
					/>
				</template>
			</div>
		</template>
		<div :class="currentStep === 'plan' ? 'w-[56rem] max-w-full' : 'w-[40rem] max-w-full'">
			<PlanSelector
				v-if="currentStep === 'plan'"
				v-model:plan="selectedPlan"
				v-model:interval="selectedInterval"
				:existing-plan="existingPlan"
				:available-products="availableProducts"
				:currency="currency"
				@choose-custom="handleChooseCustom"
				@proceed="handleProceed"
			/>
			<RegionSelector
				v-else-if="currentStep === 'region'"
				v-model:region="selectedRegion"
				v-model:plan="selectedPlan"
				:regions="regions"
				:pings="regionPings"
				:custom="customServer"
				:hide-region-selection="hideRegionSelection"
				:available-products="availableProducts"
				:currency="currency"
				:interval="selectedInterval"
				:fetch-stock="fetchStock"
			/>
			<PaymentMethodSelector
				v-else-if="currentStep === 'payment' && selectedPlan && selectedInterval"
				:payment-methods="paymentMethods"
				:selected="selectedPaymentMethod"
				:loading-elements="loadingElements"
				:loading-elements-failed="loadingElementsFailed"
				@select="selectPaymentMethod"
			/>
			<ConfirmPurchase
				v-else-if="
					currentStep === 'review' &&
					(hasPaymentMethod || noPaymentRequired) &&
					currentRegion &&
					selectedInterval &&
					selectedPlan
				"
				v-model:interval="selectedInterval"
				v-model:accepted-eula="acceptedEula"
				:currency="currency"
				:plan="selectedPlan"
				:region="currentRegion"
				:ping="currentPing"
				:loading="paymentMethodLoading"
				:selected-payment-method="selectedPaymentMethod || inputtedPaymentMethod"
				:has-payment-method="!!hasPaymentMethod"
				:tax="tax"
				:total="total"
				:no-payment-required="noPaymentRequired"
				:existing-plan="existingPlan"
				:existing-subscription="existingSubscription"
				@change-payment-method="changePaymentMethod"
				@reload-payment-intent="reloadPaymentIntent"
			/>
			<div v-else>Something went wrong</div>
			<div
				v-show="
					selectedPaymentMethod === undefined &&
					currentStep === 'payment' &&
					selectedPlan &&
					selectedInterval
				"
				class="min-h-[16rem] flex flex-col gap-2 mt-2 p-4 bg-table-alternateRow rounded-xl justify-center items-center"
			>
				<div v-show="loadingElements">
					<ModalLoadingIndicator :error="loadingElementsFailed">
						Loading...
						<template #error> Error loading Stripe payment UI. </template>
					</ModalLoadingIndicator>
				</div>
				<div class="w-full">
					<div id="address-element"></div>
					<div id="payment-element" class="mt-4"></div>
				</div>
			</div>
		</div>
		<div class="flex gap-2 justify-between mt-4">
			<Button v-if="previousStep" @click="previousStep && setStep(previousStep, true)">
				<LeftArrowIcon /> {{ formatMessage(commonMessages.backButton) }}
			</Button>
			<Button v-else-if="currentStep !== 'plan'" @click="modal?.hide()">
				<XIcon />
				{{ formatMessage(commonMessages.cancelButton) }}
			</Button>
			<Button
				v-if="currentStep !== 'plan'"
				v-tooltip="
					currentStep === 'review' && !acceptedEula && !noPaymentRequired
						? 'You must accept the Minecraft EULA to proceed.'
						: undefined
				"
				type="colored"
				color="brand"
				:disabled="!canProceed"
				@click="
					noPaymentRequired && currentStep === 'review'
						? (async () => {
								if (props.onFinalizeNoPaymentChange) {
									try {
										await props.onFinalizeNoPaymentChange()
									} catch (e) {
										return
									}
								}
								modal?.hide()
							})()
						: setStep(nextStep)
				"
			>
				<template v-if="currentStep === 'review'">
					<template v-if="noPaymentRequired"><CheckCircleIcon /> Confirm Change</template>
					<template v-else>
						<SpinnerIcon v-if="completingPurchase" class="animate-spin" />
						<CheckCircleIcon v-else />
						Subscribe
					</template>
				</template>
				<template v-else>
					{{ formatMessage(commonMessages.nextButton) }} <RightArrowIcon />
				</template>
			</Button>
		</div>
	</NewModal>
</template>
