<script setup lang="ts">
import { PlusIcon, XIcon } from '@modrinth/assets'
import type Stripe from 'stripe'
import { nextTick, ref, useTemplateRef } from 'vue'

import { Button } from '#ui/components/base/buttons'

import { defineMessages, useVIntl } from '../../composables/i18n'
import { commonMessages } from '../../utils'
import { NewModal } from '../index'
import type { AddPaymentMethodProps } from './AddPaymentMethod.vue'
import AddPaymentMethod from './AddPaymentMethod.vue'

const { formatMessage } = useVIntl()

const modal = useTemplateRef<InstanceType<typeof NewModal>>('modal')
const addPaymentMethod = useTemplateRef<InstanceType<typeof AddPaymentMethod>>('addPaymentMethod')

const props = defineProps<AddPaymentMethodProps>()
const loading = ref(false)

async function open(paymentMethods: Stripe.PaymentMethod[]) {
	modal.value?.show()
	await nextTick()
	await addPaymentMethod.value?.reload(paymentMethods)
}

const messages = defineMessages({
	addingPaymentMethod: {
		id: 'modal.add-payment-method.title',
		defaultMessage: 'Adding a payment method',
	},
	paymentMethodAdd: {
		id: 'modal.add-payment-method.action',
		defaultMessage: 'Add payment method',
	},
})

defineExpose({
	show: open,
})
</script>

<template>
	<NewModal ref="modal">
		<template #title>
			<span class="text-lg font-extrabold text-contrast">
				{{ formatMessage(messages.addingPaymentMethod) }}
			</span>
		</template>
		<div class="w-[40rem] max-w-full">
			<AddPaymentMethod
				ref="addPaymentMethod"
				:publishable-key="props.publishableKey"
				:return-url="props.returnUrl"
				:create-setup-intent="props.createSetupIntent"
				:on-error="props.onError"
				@start-loading="loading = true"
				@stop-loading="loading = false"
			/>
			<div class="input-group mt-auto pt-4">
				<Button type="colored" color="brand" :disabled="loading" @click="addPaymentMethod.submit()">
					<PlusIcon />
					{{ formatMessage(messages.paymentMethodAdd) }}
				</Button>
				<Button @click="modal.hide()">
					<XIcon />
					{{ formatMessage(commonMessages.cancelButton) }}
				</Button>
			</div>
		</div>
	</NewModal>
</template>
