<template>
	<div
		class="grid grid-cols-[min-content_auto_min-content_min-content] items-center gap-2 rounded-2xl border-[1px] border-divider bg-bg p-2"
	>
		<VersionChannelIndicator :channel="version.version_type" />
		<div class="flex min-w-0 flex-col gap-1">
			<h1 class="my-0 truncate text-nowrap text-base font-extrabold leading-none text-contrast">
				{{ version.version_number }}
			</h1>
			<p class="m-0 truncate text-nowrap text-xs font-semibold text-secondary">
				{{ version.name }}
			</p>
		</div>
		<ButtonLink
			type="colored"
			color="brand"
			:href="downloadUrl"
			:download="primaryFilename"
			class="min-w-0"
			@click="emit('onDownload')"
		>
			<DownloadIcon aria-hidden="true" /> Download
		</ButtonLink>
		<IconButton
			label="View version"
			class="min-w-0"
			@click="
				emit('onNavigate', `/project/${props.version.project_id}/version/${props.version.id}`)
			"
		>
			<ExternalIcon aria-hidden="true" />
		</IconButton>
	</div>
</template>

<script setup lang="ts">
import { DownloadIcon, ExternalIcon } from '@modrinth/assets'
import type { Version, VersionFile } from '@modrinth/utils'
import { computed } from 'vue'

import { ButtonLink, IconButton } from '#ui/components/base/buttons'

import { VersionChannelIndicator } from '../index'

const props = defineProps<{
	version: Version
	decorateDownloadUrl?: (url: string) => string
}>()

const primaryFile = computed<VersionFile>(
	() => props.version.files.find((x) => x.primary) || props.version.files[0],
)

const downloadUrl = computed(() => {
	const raw = primaryFile.value.url
	return props.decorateDownloadUrl ? props.decorateDownloadUrl(raw) : raw
})

const primaryFilename = computed(() => primaryFile.value.filename)

const emit = defineEmits<{
	onDownload: []
	onNavigate: [url: string]
}>()
</script>
