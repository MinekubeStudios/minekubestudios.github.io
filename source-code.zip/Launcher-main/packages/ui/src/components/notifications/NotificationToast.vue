<template>
	<div
		class="notification-toast relative overflow-hidden rounded-[20px] border border-solid border-surface-5 bg-surface-3 p-4 shadow-[0px_4px_8px_0px_rgba(0,0,0,0.1),0px_1px_3px_0px_rgba(0,0,0,0.2)]"
	>
		<div v-if="isInviteNotification" class="flex w-full items-start gap-3">
			<Avatar
				:src="inviteAvatarUrl"
				:alt="inviteAvatarLabel"
				:tint-by="inviteAvatarLabel"
				size="44px"
				:circle="inviteAvatarCircle"
				no-shadow
				class="border border-solid border-surface-5"
			/>
			<div class="flex min-w-0 flex-1 flex-col gap-2.5">
				<div class="flex w-full items-start gap-1">
					<p class="m-0 min-w-0 flex-1 break-words text-lg font-normal leading-6 text-contrast/85">
						<IntlFormatted
							:message-id="
								type === 'friend-request'
									? messages.friendRequest
									: type === 'server-invite'
										? messages.serverInvite
										: messages.instanceInvite
							"
							:values="{ actor: actorLabel, entity: entityLabel }"
						>
							<template #actor="{ children }">
								<button
									v-if="actorName && type !== 'friend-request'"
									type="button"
									class="m-0 inline border-0 bg-transparent p-0 text-lg font-semibold leading-6 text-contrast hover:underline"
									@click="$emit('open-actor')"
								>
									<component :is="() => children" />
								</button>
								<span v-else class="font-semibold text-contrast">
									<component :is="() => children" />
								</span>
							</template>
							<template #entity="{ children }">
								<template v-if="type === 'instance-invite'">
									<Avatar
										:src="entityIconUrl"
										:alt="entityLabel"
										:tint-by="entityLabel"
										size="28px"
										no-shadow
										raised
										class="inline-block !rounded-lg align-middle"
									/>
								</template>
								<span
									:class="{ 'ml-1': type === 'instance-invite' }"
									class="font-semibold text-contrast"
								>
									<component :is="() => children" />
								</span>
							</template>
						</IntlFormatted>
					</p>
					<IconButton
						v-if="dismissible"
						type="quiet"
						size="sm"
						:label="formatMessage(messages.dismissNotification)"
						native-type="button"
						class="notification-toast-dismiss -m-1.5"
						@click="$emit('dismiss')"
					>
						<XIcon />
					</IconButton>
				</div>
				<div class="flex items-center gap-2">
					<Button
						type="colored"
						color="brand"
						:disabled="actionLoading != null"
						@click="$emit('accept')"
					>
						<SpinnerIcon v-if="actionLoading === 'accept'" class="animate-spin" />
						<CheckIcon v-else />
						{{ formatMessage(messages.accept) }}
					</Button>
					<Button type="outlined" :disabled="actionLoading != null" @click="$emit('decline')">
						<XIcon />
						{{ formatMessage(messages.decline) }}
					</Button>
				</div>
			</div>
		</div>
		<div v-else class="flex w-full items-start gap-3">
			<Avatar
				:src="entityIconUrl"
				:alt="entityLabel"
				size="44px"
				no-shadow
				raised
				:tint-by="entityLabel"
				class="!rounded-xl border border-solid border-surface-5"
			/>
			<div class="notification-toast-main-grid min-w-0 flex-1 text-base leading-5">
				<p
					ref="titleRef"
					v-tooltip="truncatedTooltip(titleRef, entityLabel)"
					class="col-start-1 col-end-3 row-start-1 m-0 min-w-0 truncate pr-9 text-lg font-semibold leading-6 text-contrast"
				>
					{{ entityLabel }}
				</p>
				<div class="col-start-2 row-start-1 justify-self-end">
					<IconButton
						v-if="dismissible"
						type="quiet"
						size="sm"
						:label="formatMessage(messages.dismissNotification)"
						native-type="button"
						class="notification-toast-dismiss -m-1.5"
						@click="$emit('dismiss')"
					>
						<XIcon />
					</IconButton>
				</div>
				<div
					class="col-start-1 col-end-3 row-start-2 flex min-w-0 items-center justify-between gap-0.5"
				>
					<p
						ref="statusRef"
						v-tooltip="truncatedTooltip(statusRef, statusLine)"
						class="m-0 min-w-0 flex-1 font-normal leading-tight text-contrast/85"
						:class="wrapText ? 'whitespace-normal break-words' : 'truncate'"
					>
						{{ statusLine }}
					</p>
					<div
						v-if="type === 'instance-download' && progressLabel"
						class="notification-inline-progress-label flex-none text-xs"
					>
						{{ progressLabel }}
					</div>
				</div>
				<div
					v-if="type === 'instance-ready'"
					class="col-start-1 col-end-3 row-start-3 mt-2 flex min-w-0 items-center justify-between gap-2"
				>
					<div class="flex min-w-0 items-center gap-2">
						<Button type="colored" color="brand" @click="$emit('launch')">
							{{ formatMessage(messages.launchGame) }}
						</Button>
						<Button type="outlined" @click="$emit('open-instance')">
							{{ formatMessage(messages.instance) }}
						</Button>
					</div>
					<div v-if="progressLabel" class="notification-inline-progress-label flex-none">
						{{ progressLabel }}
					</div>
				</div>
				<div
					v-if="type === 'instance-download' && actions?.length"
					class="col-start-1 col-end-3 row-start-3 mt-2 flex min-w-0 flex-wrap items-center gap-2"
				>
					<Button
						v-for="(action, index) in actions"
						:key="index"
						:type="notificationButtonColor(action, index) ? 'colored' : 'base'"
						:color="notificationButtonColor(action, index)"
						@click="$emit('action', index)"
					>
						<component :is="action.icon" v-if="action.icon" />
						{{ action.label }}
					</Button>
				</div>
			</div>
		</div>
		<div
			v-if="showsBottomProgress"
			class="notification-bottom-progress-track absolute inset-x-0 bottom-0 h-1 overflow-hidden"
			role="progressbar"
			:aria-valuenow="isWaitingProgress ? undefined : progressPercent"
			aria-valuemin="0"
			aria-valuemax="100"
		>
			<div
				class="h-full transition-[left,width] duration-200 ease-in-out"
				:class="[
					type === 'instance-ready' ? 'bg-surface-5' : 'bg-brand',
					{ 'notification-bottom-progress--waiting': isWaitingProgress },
				]"
				:style="isWaitingProgress ? undefined : { width: `${progressPercent}%` }"
			/>
		</div>
	</div>
</template>

<script setup lang="ts">
import { CheckIcon, SpinnerIcon, XIcon } from '@modrinth/assets'
import { computed, ref } from 'vue'

import { Button, type ButtonColor, IconButton } from '#ui/components/base/buttons'

import { useFormatBytes, useFormatNumber } from '../../composables'
import { defineMessages, useVIntl } from '../../composables/i18n'
import type { PopupNotificationButton, PopupNotificationProgressType } from '../../providers'
import { truncatedTooltip } from '../../utils/truncate'
import Avatar from '../base/Avatar.vue'
import IntlFormatted from '../base/IntlFormatted.vue'

const { formatMessage } = useVIntl()
const messages = defineMessages({
	friendRequest: {
		id: 'notifications.friend-request.body',
		defaultMessage: '<actor>{actor}</actor> sent you a friend request.',
	},
	serverInvite: {
		id: 'notifications.server-invite.body',
		defaultMessage:
			'<actor>{actor}</actor> invited you to manage the server <entity>{entity}</entity>.',
	},
	instanceInvite: {
		id: 'notifications.instance-invite.body',
		defaultMessage: '<actor>{actor}</actor> invited you to <entity>{entity}</entity> instance.',
	},
	dismissNotification: {
		id: 'notifications.dismiss',
		defaultMessage: 'Dismiss notification',
	},
	accept: { id: 'notifications.invite.accept', defaultMessage: 'Accept' },
	decline: { id: 'notifications.invite.decline', defaultMessage: 'Decline' },
	launchGame: { id: 'notifications.instance-ready.launch-game', defaultMessage: 'Launch game' },
	instance: { id: 'notifications.instance-ready.open-instance', defaultMessage: 'Instance' },
	someone: { id: 'notifications.actor.unknown', defaultMessage: 'Someone' },
	installedReady: {
		id: 'notifications.instance-ready.status',
		defaultMessage: 'Installed and ready to play.',
	},
})

type NotificationToastType =
	| 'friend-request'
	| 'server-invite'
	| 'instance-invite'
	| 'instance-download'
	| 'instance-ready'
type NotificationToastAction = 'accept'

const props = withDefaults(
	defineProps<{
		type: NotificationToastType
		actionLoading?: NotificationToastAction | null
		actorName?: string | null
		actorAvatarUrl?: string | null
		entityName?: string
		entityIconUrl?: string | null
		statusText?: string
		progress?: number
		waiting?: boolean
		showProgress?: boolean
		wrapText?: boolean
		progressType?: PopupNotificationProgressType
		progressCurrent?: number
		progressTotal?: number
		actions?: PopupNotificationButton[]
		dismissible?: boolean
	}>(),
	{
		actionLoading: null,
		actorName: null,
		actorAvatarUrl: null,
		entityName: '',
		entityIconUrl: null,
		waiting: false,
		showProgress: true,
		wrapText: false,
		progressType: 'percentage',
		dismissible: true,
	},
)

defineEmits<{
	accept: []
	decline: []
	dismiss: []
	action: [index: number]
	launch: []
	'open-actor': []
	'open-instance': []
}>()

const isInviteNotification = computed(
	() =>
		props.type === 'friend-request' ||
		props.type === 'server-invite' ||
		props.type === 'instance-invite',
)

function notificationButtonColor(
	button: PopupNotificationButton,
	index: number,
): ButtonColor | undefined {
	const color = button.color ?? (index === 0 ? 'brand' : undefined)
	return color === 'standard' ? undefined : color
}

const actorLabel = computed(() => props.actorName || formatMessage(messages.someone))
const entityLabel = computed(() => props.entityName || '')
const inviteAvatarUrl = computed(() => props.actorAvatarUrl)
const inviteAvatarLabel = computed(() => actorLabel.value)
const inviteAvatarCircle = computed(() => true)
const progressValue = computed(() => Math.max(0, Math.min(1, props.progress ?? 0)))
const progressPercent = computed(() => Math.round(progressValue.value * 100))
const isWaitingProgress = computed(() => props.type === 'instance-download' && props.waiting)
const formatBytes = useFormatBytes()
const formatNumber = useFormatNumber()

const resolvedStatusText = computed(() => {
	if (props.type === 'instance-ready') {
		return props.statusText ?? formatMessage(messages.installedReady)
	}

	return props.statusText ?? ''
})

const statusLine = computed(() => {
	return resolvedStatusText.value
})

const showsBottomProgress = computed(
	() =>
		(props.type === 'instance-download' && props.showProgress) ||
		(props.type === 'instance-ready' && props.progress != null),
)

const progressCurrent = computed(() => {
	if (props.progressCurrent != null) {
		return Math.max(0, props.progressCurrent)
	}
	if (props.progressTotal != null) {
		return Math.round(progressValue.value * props.progressTotal)
	}
	return progressPercent.value
})

const progressTotal = computed(() => Math.max(0, props.progressTotal ?? 0))

function formatProgressLabel(
	type: PopupNotificationProgressType | undefined,
	current: number,
	total: number,
): string {
	if (type === 'bytes' && total > 0) {
		return `${formatBytes(Math.min(current, total), 1)} / ${formatBytes(total, 1)}`
	}

	if (type === 'count' && total > 0) {
		return `${formatNumber(Math.min(current, total))} / ${formatNumber(total)}`
	}

	return `${progressPercent.value}%`
}

const progressLabel = computed(() => {
	if (!showsBottomProgress.value || isWaitingProgress.value) {
		return ''
	}

	const primary = formatProgressLabel(
		props.progressType,
		progressCurrent.value,
		progressTotal.value,
	)
	return primary
})

const titleRef = ref<HTMLElement | null>(null)
const statusRef = ref<HTMLElement | null>(null)
</script>

<style scoped>
.notification-toast {
	width: min(420px, calc(100vw - 1.5rem));
}

.notification-toast-main-grid {
	display: grid;
	grid-template-columns: minmax(0, 1fr) auto;
	column-gap: 0.25rem;
	row-gap: 0.1875rem;
}

.notification-inline-progress-label {
	flex: 0 0 auto;
	color: var(--color-secondary);
	font-variant-numeric: tabular-nums;
	pointer-events: none;
	text-align: right;
	white-space: nowrap;
}

.notification-toast-dismiss {
	--_height: 1.25rem;
	--_width: 1.25rem;
	--_padding-x: 0;
	--_padding-y: 0;
	--_icon-size: 1.25rem;
	--_box-shadow: none;
	--_text: var(--color-base);
	--_hover-bg: transparent;
	--_hover-text: var(--color-contrast);
}

.notification-bottom-progress--waiting {
	animation: notification-bottom-progress-waiting 1s linear infinite;
	position: relative;
	width: 20%;
}

@keyframes notification-bottom-progress-waiting {
	0% {
		left: -20%;
	}

	100% {
		left: 100%;
	}
}

.notification-bottom-progress-track {
	background-color: color-mix(in srgb, var(--surface-2) 50%, transparent);
}
</style>
