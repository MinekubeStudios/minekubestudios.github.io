<template>
	<Admonition
		:type="op.state === 'done' ? 'success' : op.state?.startsWith('fail') ? 'critical' : 'info'"
		:dismissible="dismissible && isTerminal"
		:progress="'progress' in op ? (op.progress ?? 0) : 0"
		:progress-color="op.state === 'done' ? 'green' : op.state?.startsWith('fail') ? 'red' : 'blue'"
		:waiting="!isTerminal && (op.state === 'queued' || !op.progress || op.progress === 0)"
		@dismiss="$emit('dismiss')"
	>
		<template #icon="{ iconClass }">
			<FolderArchiveIcon v-if="op.op === 'zip'" :class="iconClass" />
			<PackageOpenIcon v-else :class="iconClass" />
		</template>
		<template #header>{{ title }}</template>
		<span class="text-secondary">
			<span v-if="op.state?.startsWith('fail') && op.error">
				{{ op.error }}
			</span>
			<span v-else-if="op.op === 'zip'">
				{{ formatMessage(messages.compressed, { progress: Math.round((op.progress ?? 0) * 100) }) }}
			</span>
			<span v-else>
				{{
					formatMessage(messages.extracted, {
						size: formatBytes(op.bytes_processed ?? 0),
					})
				}}
			</span>
			<span v-if="'current_file' in op && op.current_file">
				. {{ formatMessage(messages.currentFile, { file: op.current_file?.split('/')?.pop() }) }}
			</span>
		</span>
		<template v-if="op.id" #top-right-actions>
			<Button
				v-if="!isTerminal && op.cancellable !== false"
				v-tooltip="!canWriteFiles ? permissionDeniedMessage : undefined"
				type="outlined"
				class="!border !text-blue [&>svg]:!text-blue !shadow-[inset_0_0_0_1px_var(--color-blue)]"
				native-type="button"
				:disabled="!canWriteFiles"
				@click="cancelOperation"
			>
				{{ formatMessage(commonMessages.cancelButton) }}
			</Button>
		</template>
	</Admonition>
</template>

<script setup lang="ts">
import { FolderArchiveIcon, PackageOpenIcon } from '@modrinth/assets'
import { computed } from 'vue'

import Admonition from '#ui/components/base/Admonition.vue'
import { Button } from '#ui/components/base/buttons'
import { useFormatBytes } from '#ui/composables'
import { defineMessages, useVIntl } from '#ui/composables/i18n'
import { useServerPermissions } from '#ui/composables/server-permissions'
import type { FileOperation } from '#ui/layouts/shared/files-tab/types'
import { injectModrinthServerContext } from '#ui/providers'
import { commonMessages } from '#ui/utils/common-messages'

defineEmits<{ dismiss: [] }>()

const props = defineProps<{
	op: FileOperation
	dismissible: boolean
}>()

const { formatMessage } = useVIntl()
const formatBytes = useFormatBytes()
const ctx = injectModrinthServerContext()
const { canWriteFiles, permissionDeniedMessage } = useServerPermissions()

const messages = defineMessages({
	extracting: {
		id: 'files.operations.extracting',
		defaultMessage: 'Extracting {source}',
	},
	extractingCompleted: {
		id: 'files.operations.extracting-completed',
		defaultMessage: 'Extracting {source} finished',
	},
	extractingFailed: {
		id: 'files.operations.extracting-failed',
		defaultMessage: 'Extracting {source} failed',
	},
	modpackFromUrl: {
		id: 'files.operations.modpack-from-url',
		defaultMessage: 'modpack from URL',
	},
	extracted: {
		id: 'files.operations.extracted',
		defaultMessage: '{size} extracted',
	},
	currentFile: {
		id: 'files.operations.current-file',
		defaultMessage: 'Current file: {file}',
	},
	compressing: {
		id: 'files.operations.compressing',
		defaultMessage: 'Creating {source}',
	},
	compressingCompleted: {
		id: 'files.operations.compressing-completed',
		defaultMessage: 'Creating {source} finished',
	},
	compressingFailed: {
		id: 'files.operations.compressing-failed',
		defaultMessage: 'Creating {source} failed',
	},
	compressed: {
		id: 'files.operations.compressed',
		defaultMessage: '{progress}% compressed',
	},
})

const isTerminal = computed(() => props.op.state === 'done' || !!props.op.state?.startsWith('fail'))
const sourceName = computed(() =>
	props.op.src.includes('https://') ? formatMessage(messages.modpackFromUrl) : props.op.src,
)

const title = computed(() => {
	if (props.op.op === 'zip') {
		if (props.op.state === 'done') {
			return formatMessage(messages.compressingCompleted, { source: sourceName.value })
		}
		if (props.op.state?.startsWith('fail')) {
			return formatMessage(messages.compressingFailed, { source: sourceName.value })
		}
		return formatMessage(messages.compressing, { source: sourceName.value })
	}
	if (props.op.state === 'done') {
		return formatMessage(messages.extractingCompleted, { source: sourceName.value })
	}
	if (props.op.state?.startsWith('fail')) {
		return formatMessage(messages.extractingFailed, { source: sourceName.value })
	}
	return formatMessage(messages.extracting, { source: sourceName.value })
})

function cancelOperation() {
	if (!canWriteFiles.value || !props.op.id) return
	ctx.dismissOperation(props.op.id, 'cancel')
}
</script>
