import type { RouteLocationRaw } from 'vue-router'

import type { AuditActor, AuditWorld, ParsedAuditEvent } from './events/types'

export type ServerAccessRole = 'owner' | 'editor' | 'viewer'
export type ServerAccessUserProfileLink =
	| RouteLocationRaw
	| (() => void | Promise<void>)
	| undefined

export interface ServerAccessUser extends AuditActor {
	id: string
	username: string
	avatarUrl?: string
}

export interface ServerAccessMember {
	id: string
	user: ServerAccessUser
	role: ServerAccessRole
	joinedAt: string | null
	inviteResendAvailableAt?: string | null
	pending?: boolean
	isOwner?: boolean
}

export interface ServerAuditLogEntry {
	id: string
	actor: AuditActor
	world: AuditWorld | null
	event: ParsedAuditEvent
	timestamp: string
}

export interface ServerAuditLogFilters {
	userId: string | null
	worldId: string | null
}

export interface ServerAccessRoleOption {
	value: ServerAccessRole
	label: string
	description?: string
}

export interface ServerAccessInviteSuggestion {
	id: string
	username: string
	avatarUrl?: string
	email?: string
}

export interface GrantServerAccessPayload {
	target: string
	user: ServerAccessInviteSuggestion
	role: Exclude<ServerAccessRole, 'owner'>
	addAsFriend: boolean
}

export interface ServerListingOwner {
	username: string
	avatarUrl?: string
}
