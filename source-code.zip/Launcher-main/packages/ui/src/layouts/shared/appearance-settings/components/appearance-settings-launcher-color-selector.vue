<script setup lang="ts">
import { computed } from 'vue'

import { useVIntl } from '#ui/composables/i18n'

import {
	isLauncherColorHex,
	LAUNCHER_COLOR_PRESETS,
	LAUNCHER_COLOR_THEME,
	normalizeLauncherColorHex,
} from '../launcher-colors'
import { appearanceSettingsMessages } from '../messages'

const { formatMessage } = useVIntl()

const props = defineProps<{
	modelValue: string
}>()

const emit = defineEmits<{
	'update:modelValue': [value: string]
}>()

const presetLabels: Record<string, { id: string; defaultMessage: string }> = {
	gold: appearanceSettingsMessages.launcherColorGold,
	tangerine: appearanceSettingsMessages.launcherColorTangerine,
	magenta: appearanceSettingsMessages.launcherColorMagenta,
	rose: appearanceSettingsMessages.launcherColorRose,
	violet: appearanceSettingsMessages.launcherColorViolet,
	sapphire: appearanceSettingsMessages.launcherColorSapphire,
	aqua: appearanceSettingsMessages.launcherColorAqua,
	emerald: appearanceSettingsMessages.launcherColorEmerald,
	lime: appearanceSettingsMessages.launcherColorLime,
}

const customHex = computed(() => {
	if (isLauncherColorHex(props.modelValue)) return normalizeLauncherColorHex(props.modelValue)
	return '#fc0060'
})

const isCustomSelected = computed(() => {
	if (!isLauncherColorHex(props.modelValue)) return false
	const hex = normalizeLauncherColorHex(props.modelValue)
	return !LAUNCHER_COLOR_PRESETS.some((preset) => normalizeLauncherColorHex(preset.hex) === hex)
})

function labelFor(presetId: string): string {
	const message = presetLabels[presetId]
	return message ? formatMessage(message) : presetId
}

function selectPreset(hex: string): void {
	emit('update:modelValue', normalizeLauncherColorHex(hex))
}

function selectTheme(): void {
	emit('update:modelValue', LAUNCHER_COLOR_THEME)
}

function onCustomInput(event: Event): void {
	const target = event.target as HTMLInputElement
	emit('update:modelValue', normalizeLauncherColorHex(target.value))
}
</script>

<template>
	<div class="launcher-color-picker">
		<button
			v-tooltip="formatMessage(appearanceSettingsMessages.launcherColorTheme)"
			type="button"
			class="color-swatch theme-swatch"
			:class="{ selected: modelValue === LAUNCHER_COLOR_THEME }"
			:aria-label="formatMessage(appearanceSettingsMessages.launcherColorTheme)"
			:aria-pressed="modelValue === LAUNCHER_COLOR_THEME"
			@click="selectTheme"
		>
			<span class="swatch-face theme-face" aria-hidden="true"></span>
		</button>

		<button
			v-for="preset in LAUNCHER_COLOR_PRESETS"
			:key="preset.id"
			v-tooltip="labelFor(preset.id)"
			type="button"
			class="color-swatch"
			:class="{
				selected:
					isLauncherColorHex(modelValue) &&
					normalizeLauncherColorHex(modelValue) === normalizeLauncherColorHex(preset.hex),
			}"
			:aria-label="labelFor(preset.id)"
			:aria-pressed="
				isLauncherColorHex(modelValue) &&
				normalizeLauncherColorHex(modelValue) === normalizeLauncherColorHex(preset.hex)
			"
			@click="selectPreset(preset.hex)"
		>
			<span class="swatch-face" :style="{ background: preset.hex }" aria-hidden="true"></span>
		</button>

		<label
			v-tooltip="formatMessage(appearanceSettingsMessages.launcherColorCustom)"
			class="color-swatch custom-swatch"
			:class="{ selected: isCustomSelected }"
		>
			<span class="swatch-face custom-face" :style="{ background: customHex }" aria-hidden="true">
				<input
					type="color"
					class="custom-input"
					:value="customHex"
					:aria-label="formatMessage(appearanceSettingsMessages.launcherColorCustom)"
					@input="onCustomInput"
				/>
			</span>
		</label>

		<span v-if="isCustomSelected" class="custom-hex" aria-hidden="true">{{ customHex }}</span>
	</div>
</template>

<style lang="scss" scoped>
.launcher-color-picker {
	display: flex;
	flex-wrap: wrap;
	align-items: center;
	gap: var(--gap-md);
}

.color-swatch {
	appearance: none;
	border: none;
	background: transparent;
	padding: 0;
	cursor: pointer;
	border-radius: var(--radius-max, 999px);

	&:focus-visible {
		outline: 2px solid var(--color-focus-ring);
		outline-offset: 2px;
	}
}

.swatch-face {
	display: block;
	width: 2.35rem;
	height: 2.35rem;
	border-radius: var(--radius-max, 999px);
	border: 2px solid var(--color-divider);
	box-shadow:
		inset 0 -3px 6px rgba(0, 0, 0, 0.22),
		inset 0 2px 3px rgba(255, 255, 255, 0.28);
	transition:
		transform 0.12s ease-in-out,
		border-color 0.12s ease-in-out,
		box-shadow 0.12s ease-in-out;
	position: relative;
	overflow: hidden;

	.color-swatch:hover & {
		transform: scale(1.08);
	}

	.color-swatch.selected & {
		border-color: var(--color-contrast);
		box-shadow:
			0 0 0 2px var(--color-brand),
			inset 0 -3px 6px rgba(0, 0, 0, 0.22),
			inset 0 2px 3px rgba(255, 255, 255, 0.28);
	}
}

.theme-face {
	background: conic-gradient(
		from 210deg,
		#fcc000,
		#ff6a00,
		#fc0060,
		#8b5cf6,
		#2b7fff,
		#00d7c7,
		#1bd96a,
		#fcc000
	);
}

.custom-face {
	cursor: pointer;
}

.custom-input {
	position: absolute;
	inset: 0;
	opacity: 0;
	width: 100%;
	height: 100%;
	border: none;
	padding: 0;
	cursor: pointer;
}

.custom-hex {
	font-family: monospace;
	font-size: 0.85rem;
	color: var(--color-secondary);
	text-transform: uppercase;
}
</style>
